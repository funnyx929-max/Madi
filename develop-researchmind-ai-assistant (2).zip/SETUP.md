# ResearchMind Setup Guide

## Quick Start

### 1. Environment Setup

Create a `.env` file in the project root:

```env
# Database (Required)
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db

# OpenAI API (Required for AI features)
OPENAI_API_KEY=sk-your-openai-api-key-here

# Semantic Scholar API (Optional - for higher rate limits)
SEMANTIC_SCHOLAR_API_KEY=your-semantic-scholar-api-key
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Database Setup

Initialize the database schema:

```bash
# Push schema to PostgreSQL
npx drizzle-kit push
```

### 4. Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## API Keys

### OpenAI API Key (Required)

ResearchMind uses OpenAI's GPT-4o-mini for AI features:
- Paper explanations
- Literature reviews
- Research gap analysis
- Citation generation
- Flashcard generation
- AI chat mentor

**Get your key:** [OpenAI Platform](https://platform.openai.com/api-keys)

### Semantic Scholar API Key (Optional)

Increases rate limits for paper search:
- Without key: ~100 requests/5 minutes
- With key: ~5000 requests/5 minutes

**Get your key:** [Semantic Scholar API](https://www.semanticscholar.org/product/api)

---

## Features Overview

### Paper Search

Search across multiple academic databases:

```typescript
// Example: Search for papers
const response = await fetch('/api/search?q=transformers&sources=semanticscholar,openalex&limit=20');
const data = await response.json();
```

Query parameters:
- `q` - Search query (required)
- `sources` - Comma-separated list: `semanticscholar,openalex,arxiv`
- `limit` - Number of results (default: 10)
- `yearMin` - Minimum publication year
- `yearMax` - Maximum publication year
- `citationMin` - Minimum citation count
- `openAccess` - true/false for open access only

### AI Explanation

Generate explanations at different levels:

```typescript
// Example: Explain a paper
const response = await fetch('/api/ai/explain', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    paper: {
      title: 'Attention Is All You Need',
      abstract: '...',
    },
    level: 'undergraduate', // beginner | undergraduate | graduate | expert
  }),
});
const data = await response.json();
console.log(data.explanation);
```

### Literature Review Generation

```typescript
// Example: Generate literature review
const response = await fetch('/api/ai/literature-review', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    papers: [
      { title: 'Paper 1', abstract: '...', year: 2020 },
      { title: 'Paper 2', abstract: '...', year: 2021 },
    ],
    focusArea: 'transformer architectures',
  }),
});
const data = await response.json();
console.log(data.review);
// { introduction, sections: [{ title, content }], conclusion }
```

### Research Gap Finder

```typescript
// Example: Find research gaps
const response = await fetch('/api/ai/research-gaps', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    papers: [
      { title: 'Paper 1', abstract: '...' },
      { title: 'Paper 2', abstract: '...' },
    ],
  }),
});
const data = await response.json();
console.log(data.gaps);
// [{ title, description, category, severity }]
```

### Citation Generation

```typescript
// Example: Generate citation
const response = await fetch('/api/ai/citation', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    paper: {
      title: 'Attention Is All You Need',
      authors: [{ name: 'Vaswani et al.' }],
      year: 2017,
      venue: 'NeurIPS',
    },
    style: 'apa', // apa | mla | ieee | chicago | bibtex
  }),
});
const data = await response.json();
console.log(data.citation);
```

### AI Chat

```typescript
// Example: Chat with AI mentor
const response = await fetch('/api/ai/chat', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    question: 'Explain the transformer architecture',
    papers: [{ title: 'Attention Is All You Need', abstract: '...' }],
    chatHistory: [
      { role: 'user', content: 'Previous question' },
      { role: 'assistant', content: 'Previous answer' },
    ],
  }),
});
const data = await response.json();
console.log(data.answer);
```

---

## Database Schema

### Users
- Profile and preferences
- Reading history
- Favorite topics

### Papers
- Metadata from external APIs
- Abstract, authors, citations
- Fields and keywords

### Projects
- User collections
- Organize papers by topic
- Shared projects (planned)

### Notes & Highlights
- Annotations on papers
- Page-specific notes
- Color-coded highlights

### AI Chats
- Conversation history
- Context-aware responses
- Paper associations

### Study Sessions
- Reading time tracking
- Progress monitoring
- Analytics

---

## Development

### Type Checking

```bash
npm run typecheck
```

### Build Production

```bash
npm run build
npm start
```

### Database Migrations

```bash
# Generate migration
npx drizzle-kit generate

# Push to database
npx drizzle-kit push

# Studio (database GUI)
npx drizzle-kit studio
```

---

## Deployment

### Environment Variables

Ensure these are set in production:

- `DATABASE_URL` - PostgreSQL connection string
- `OPENAI_API_KEY` - OpenAI API key
- `SEMANTIC_SCHOLAR_API_KEY` (optional)

### Database

1. Create PostgreSQL database
2. Run `npx drizzle-kit push` to apply schema
3. Verify connection

### Build

```bash
npm run build
```

### Start

```bash
npm start
```

---

## Troubleshooting

### "Missing credentials" error

Ensure `OPENAI_API_KEY` is set in your `.env` file.

### Database connection failed

Check that PostgreSQL is running and `DATABASE_URL` is correct.

### Paper search returns empty

- Check internet connection
- Verify API endpoints are accessible
- Try different search terms

### AI features not working

- Verify OpenAI API key is valid
- Check API quota and billing
- Review rate limits

---

## API Rate Limits

### Semantic Scholar
- Without key: ~100 requests per 5 minutes
- With key: ~5000 requests per 5 minutes

### OpenAlex
- No authentication required
- Rate limit: ~10 requests per second
- Use polite pool (set User-Agent)

### arXiv
- No authentication required
- Rate limit: ~3 requests per second
- Respect `<opensearch:totalResults>`

### OpenAI
- Varies by plan
- Check: [OpenAI Usage](https://platform.openai.com/usage)

---

## Best Practices

### Search Optimization

- Use specific keywords
- Apply filters to narrow results
- Combine multiple sources
- Check open access when possible

### AI Feature Usage

- Start with undergraduate level
- Provide context for better responses
- Review generated content
- Cite sources properly

### Performance

- Cache API responses when possible
- Batch operations
- Use database indexes
- Optimize images and assets

---

## Support

For issues, questions, or contributions:
- Open an issue on GitHub
- Check existing discussions
- Review documentation

---

**Happy Researching! 🎓**
