import { NextRequest, NextResponse } from 'next/server';
import { explainPaper } from '@/lib/openai';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { paper, level = 'undergraduate' } = body;

    if (!paper || !paper.title) {
      return NextResponse.json(
        { error: 'Paper data is required' },
        { status: 400 }
      );
    }

    const explanation = await explainPaper(paper, level);

    return NextResponse.json({ explanation });
  } catch (error) {
    console.error('Explanation error:', error);
    return NextResponse.json(
      { error: 'Failed to generate explanation' },
      { status: 500 }
    );
  }
}
