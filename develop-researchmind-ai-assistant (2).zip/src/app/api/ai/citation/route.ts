import { NextRequest, NextResponse } from 'next/server';
import { generateCitation } from '@/lib/openai';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { paper, style = 'apa' } = body;

    if (!paper || !paper.title) {
      return NextResponse.json(
        { error: 'Paper data is required' },
        { status: 400 }
      );
    }

    const citation = await generateCitation(paper, style);

    return NextResponse.json({ citation, style });
  } catch (error) {
    console.error('Citation error:', error);
    return NextResponse.json(
      { error: 'Failed to generate citation' },
      { status: 500 }
    );
  }
}
