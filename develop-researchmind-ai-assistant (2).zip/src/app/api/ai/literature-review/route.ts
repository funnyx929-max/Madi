import { NextRequest, NextResponse } from 'next/server';
import { generateLiteratureReview } from '@/lib/openai';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { papers, focusArea } = body;

    if (!papers || !Array.isArray(papers) || papers.length === 0) {
      return NextResponse.json(
        { error: 'Papers array is required' },
        { status: 400 }
      );
    }

    const review = await generateLiteratureReview(papers, focusArea);

    return NextResponse.json({ review });
  } catch (error) {
    console.error('Literature review error:', error);
    return NextResponse.json(
      { error: 'Failed to generate literature review' },
      { status: 500 }
    );
  }
}
