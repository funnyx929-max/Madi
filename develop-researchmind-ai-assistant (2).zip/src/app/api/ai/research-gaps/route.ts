import { NextRequest, NextResponse } from 'next/server';
import { findResearchGaps } from '@/lib/openai';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { papers } = body;

    if (!papers || !Array.isArray(papers) || papers.length === 0) {
      return NextResponse.json(
        { error: 'Papers array is required' },
        { status: 400 }
      );
    }

    const gaps = await findResearchGaps(papers);

    return NextResponse.json({ gaps });
  } catch (error) {
    console.error('Research gaps error:', error);
    return NextResponse.json(
      { error: 'Failed to find research gaps' },
      { status: 500 }
    );
  }
}
