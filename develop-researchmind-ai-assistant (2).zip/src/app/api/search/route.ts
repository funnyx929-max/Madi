import { NextRequest, NextResponse } from 'next/server';
import { searchPapers, SearchFilters } from '@/lib/paper-search';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const query = searchParams.get('q');
    const sources = searchParams.get('sources')?.split(',') as any[] || ['semanticscholar', 'openalex'];
    const limit = parseInt(searchParams.get('limit') || '10');

    if (!query) {
      return NextResponse.json(
        { error: 'Query parameter is required' },
        { status: 400 }
      );
    }

    // Parse filters
    const filters: SearchFilters = {};
    
    const yearMin = searchParams.get('yearMin');
    const yearMax = searchParams.get('yearMax');
    if (yearMin || yearMax) {
      filters.year = {
        min: yearMin ? parseInt(yearMin) : undefined,
        max: yearMax ? parseInt(yearMax) : undefined,
      };
    }

    const citationMin = searchParams.get('citationMin');
    if (citationMin) {
      filters.citationCount = { min: parseInt(citationMin) };
    }

    const fields = searchParams.get('fields');
    if (fields) {
      filters.fields = fields.split(',');
    }

    const openAccess = searchParams.get('openAccess');
    if (openAccess === 'true') {
      filters.isOpenAccess = true;
    }

    const results = await searchPapers(query, sources, filters, limit);

    return NextResponse.json({ results, count: results.length });
  } catch (error) {
    console.error('Search error:', error);
    return NextResponse.json(
      { error: 'Failed to search papers' },
      { status: 500 }
    );
  }
}
