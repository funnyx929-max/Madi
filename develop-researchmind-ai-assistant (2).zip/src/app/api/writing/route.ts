import { NextRequest, NextResponse } from 'next/server';
import { openai } from '@/lib/openai';

export async function POST(request: NextRequest) {
  try {
    const { text, mode = 'improve' } = await request.json();

    if (!text) {
      return NextResponse.json(
        { error: 'Text is required' },
        { status: 400 }
      );
    }

    const modePrompts: Record<string, string> = {
      improve: `You are an expert academic writing assistant. Improve the following text for clarity, academic tone, and logical flow. Maintain the original meaning. Return the improved text along with specific suggestions.`,
      clarify: `You are an academic writing assistant. Rewrite the following text for maximum clarity and readability while maintaining academic rigor. Simplify complex sentences without losing technical accuracy.`,
      argument: `You are an expert academic reviewer. Analyze the following text and suggest stronger arguments. Identify weak claims, unsupported assertions, and logical gaps. Provide specific suggestions for improvement.`,
      citations: `You are an expert academic advisor. Read the following text and identify claims that would benefit from citations. Suggest where to add references and what type of sources would be appropriate.`,
    };

    const prompt = modePrompts[mode] || modePrompts.improve;

    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: `${prompt}\n\nReturn the response as JSON with: { improved: string, suggestions: string[] }` },
        { role: 'user', content: text },
      ],
      temperature: 0.7,
      max_tokens: 2000,
      response_format: { type: 'json_object' },
    });

    const content = response.choices[0]?.message?.content;
    if (!content) {
      throw new Error('Failed to generate response');
    }

    return NextResponse.json(JSON.parse(content));
  } catch (error) {
    console.error('Writing assistant error:', error);
    return NextResponse.json(
      { error: 'Failed to improve text' },
      { status: 500 }
    );
  }
}
