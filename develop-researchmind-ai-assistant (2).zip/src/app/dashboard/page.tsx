'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';
import toast from 'react-hot-toast';
import {
  Brain,
  BookOpen,
  TrendingUp,
  Clock,
  Award,
  FileText,
  Sparkles,
  Target,
  LogOut,
  User,
} from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';

export default function DashboardPage() {
  const router = useRouter();
  const { user, logout } = useAuth();
  
  const [stats] = useState({
    papersRead: 47,
    readingStreak: 12,
    totalReadingTime: 2340, // minutes
    favoriteTopics: [
      { topic: 'Machine Learning', count: 23 },
      { topic: 'Natural Language Processing', count: 15 },
      { topic: 'Computer Vision', count: 9 },
    ],
  });

  const [recentPapers] = useState([
    {
      id: '1',
      title: 'Attention Is All You Need',
      authors: 'Vaswani et al.',
      progress: 100,
      status: 'completed',
    },
    {
      id: '2',
      title: 'BERT: Pre-training of Deep Bidirectional Transformers',
      authors: 'Devlin et al.',
      progress: 65,
      status: 'reading',
    },
    {
      id: '3',
      title: 'GPT-4 Technical Report',
      authors: 'OpenAI',
      progress: 0,
      status: 'to-read',
    },
  ]);

  const [recommendations] = useState([
    {
      title: 'Explore more papers on transformer architectures',
      reason: 'Based on your recent reading history',
      icon: <Sparkles className="w-5 h-5" />,
    },
    {
      title: 'Review papers you marked as "to-read"',
      reason: 'You have 8 papers in your reading list',
      icon: <BookOpen className="w-5 h-5" />,
    },
    {
      title: 'Generate a literature review',
      reason: 'Combine insights from 15+ papers you\'ve read',
      icon: <FileText className="w-5 h-5" />,
    },
  ]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 dark:from-slate-900 dark:via-slate-900 dark:to-slate-800">
      {/* Navigation */}
      <nav className="border-b border-slate-200 dark:border-slate-700 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold gradient-text">ResearchMind</h1>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="sm" onClick={() => router.push('/')}>
                Search
              </Button>
              <Button variant="ghost" size="sm">Dashboard</Button>
              <Button variant="ghost" size="sm" onClick={() => router.push('/tools')}>
                Tools
              </Button>
              {user ? (
                <>
                  <Button variant="ghost" size="sm" onClick={() => router.push('/profile')}>
                    <User className="w-5 h-5" />
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => { logout(); router.push('/'); }}>
                    <LogOut className="w-5 h-5" />
                  </Button>
                </>
              ) : (
                <Button size="sm" onClick={() => router.push('/auth/login')}>
                  Sign In
                </Button>
              )}
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-slate-900 dark:text-slate-100 mb-2">
            {user ? `Welcome, ${user.name}! 👋` : 'Welcome back! 👋'}
          </h2>
          <p className="text-slate-600 dark:text-slate-400">
            Here's your research progress and insights
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                  <BookOpen className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                </div>
                <Badge variant="primary">+5 this week</Badge>
              </div>
              <div className="text-3xl font-bold text-slate-900 dark:text-slate-100">
                {stats.papersRead}
              </div>
              <div className="text-sm text-slate-600 dark:text-slate-400">
                Papers Read
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <div className="w-10 h-10 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-green-600 dark:text-green-400" />
                </div>
                <Badge variant="success">🔥 On fire!</Badge>
              </div>
              <div className="text-3xl font-bold text-slate-900 dark:text-slate-100">
                {stats.readingStreak}
              </div>
              <div className="text-sm text-slate-600 dark:text-slate-400">
                Day Streak
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center">
                  <Clock className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                </div>
              </div>
              <div className="text-3xl font-bold text-slate-900 dark:text-slate-100">
                {Math.floor(stats.totalReadingTime / 60)}h
              </div>
              <div className="text-sm text-slate-600 dark:text-slate-400">
                Reading Time
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <div className="w-10 h-10 bg-yellow-100 dark:bg-yellow-900 rounded-lg flex items-center justify-center">
                  <Award className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
                </div>
              </div>
              <div className="text-3xl font-bold text-slate-900 dark:text-slate-100">
                {stats.favoriteTopics.length}
              </div>
              <div className="text-sm text-slate-600 dark:text-slate-400">
                Top Topics
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Recent Papers */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <h3 className="text-xl font-semibold text-slate-900 dark:text-slate-100">
                  Continue Reading
                </h3>
              </CardHeader>
              <CardContent className="p-0">
                <div className="divide-y divide-slate-200 dark:divide-slate-700">
                  {recentPapers.map((paper) => (
                    <div key={paper.id} className="p-6 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <h4 className="font-semibold text-slate-900 dark:text-slate-100 mb-1">
                            {paper.title}
                          </h4>
                          <p className="text-sm text-slate-600 dark:text-slate-400">
                            {paper.authors}
                          </p>
                        </div>
                        <Badge
                          variant={
                            paper.status === 'completed'
                              ? 'success'
                              : paper.status === 'reading'
                              ? 'warning'
                              : 'default'
                          }
                        >
                          {paper.status === 'completed'
                            ? 'Completed'
                            : paper.status === 'reading'
                            ? 'Reading'
                            : 'To Read'}
                        </Badge>
                      </div>
                      <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full ${
                            paper.status === 'completed'
                              ? 'bg-green-500'
                              : paper.status === 'reading'
                              ? 'bg-blue-500'
                              : 'bg-slate-400'
                          }`}
                          style={{ width: `${paper.progress}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Favorite Topics */}
            <Card className="mt-6">
              <CardHeader>
                <h3 className="text-xl font-semibold text-slate-900 dark:text-slate-100">
                  Your Research Interests
                </h3>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {stats.favoriteTopics.map((topic, idx) => (
                    <div key={idx}>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
                          {topic.topic}
                        </span>
                        <span className="text-sm text-slate-600 dark:text-slate-400">
                          {topic.count} papers
                        </span>
                      </div>
                      <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                        <div
                          className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full"
                          style={{
                            width: `${(topic.count / stats.papersRead) * 100}%`,
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recommendations */}
          <div>
            <Card>
              <CardHeader>
                <h3 className="text-xl font-semibold text-slate-900 dark:text-slate-100">
                  AI Recommendations
                </h3>
              </CardHeader>
              <CardContent className="p-0">
                <div className="divide-y divide-slate-200 dark:divide-slate-700">
                  {recommendations.map((rec, idx) => (
                    <div
                      key={idx}
                      className="p-4 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                      onClick={() => {
                        if (rec.title.includes('transformer')) {
                          router.push('/?q=transformer+architectures');
                        } else if (rec.title.includes('to-read')) {
                          toast.success('Opening your reading list...');
                        } else if (rec.title.includes('literature')) {
                          router.push('/tools?tab=literature');
                        }
                      }}
                    >
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center flex-shrink-0">
                          {rec.icon}
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-slate-900 dark:text-slate-100 mb-1 text-sm">
                            {rec.title}
                          </h4>
                          <p className="text-xs text-slate-600 dark:text-slate-400">
                            {rec.reason}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="mt-6">
              <CardHeader>
                <h3 className="text-xl font-semibold text-slate-900 dark:text-slate-100">
                  Quick Actions
                </h3>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  className="w-full justify-start" 
                  variant="outline"
                  onClick={() => router.push('/tools?tab=literature')}
                >
                  <FileText className="w-4 h-4 mr-2" />
                  Generate Literature Review
                </Button>
                <Button 
                  className="w-full justify-start" 
                  variant="outline"
                  onClick={() => router.push('/tools?tab=gaps')}
                >
                  <Target className="w-4 h-4 mr-2" />
                  Find Research Gaps
                </Button>
                <Button 
                  className="w-full justify-start" 
                  variant="outline"
                  onClick={() => router.push('/tools?tab=chat')}
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  AI Research Mentor
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
