'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';
import toast from 'react-hot-toast';
import { 
  Brain, 
  Search, 
  BookOpen, 
  Lightbulb, 
  Network, 
  FileText,
  TrendingUp,
  Sparkles,
  Users,
  MessageSquare,
  LogOut,
  User
} from 'lucide-react';
import { SearchBar } from '@/components/SearchBar';
import { PaperCard } from '@/components/PaperCard';
import { PaperModal } from '@/components/PaperModal';
import { Button } from '@/components/ui/Button';
import { Card, CardContent } from '@/components/ui/Card';

export default function HomePage() {
  const router = useRouter();
  const { user, logout } = useAuth();
  const [papers, setPapers] = useState<any[]>([]);
  const [selectedPaper, setSelectedPaper] = useState<any>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [activeView, setActiveView] = useState<'hero' | 'search' | 'literature-review' | 'research-gaps'>('hero');
  const [selectedPapers, setSelectedPapers] = useState<any[]>([]);

  const handleSearch = async (query: string, filters: any) => {
    setIsSearching(true);
    setActiveView('search');
    
    try {
      const params = new URLSearchParams({
        q: query,
        sources: filters.sources.join(','),
        limit: '20',
      });

      if (filters.yearMin) params.append('yearMin', filters.yearMin);
      if (filters.yearMax) params.append('yearMax', filters.yearMax);
      if (filters.citationMin) params.append('citationMin', filters.citationMin);
      if (filters.openAccess) params.append('openAccess', 'true');

      const response = await fetch(`/api/search?${params}`);
      const data = await response.json();
      
      setPapers(data.results || []);
    } catch (error) {
      console.error('Search failed:', error);
      setPapers([]);
    } finally {
      setIsSearching(false);
    }
  };

  const handlePaperSelect = (paper: any) => {
    setSelectedPaper(paper);
    setShowModal(true);
  };

  const handleGenerateLiteratureReview = async () => {
    if (selectedPapers.length === 0) {
      toast.error('Please select papers first');
      return;
    }

    if (selectedPapers.length < 2) {
      toast.error('Please select at least 2 papers');
      return;
    }

    toast.success('Generating literature review...');
    router.push('/tools?tab=literature&papers=' + encodeURIComponent(JSON.stringify(selectedPapers)));
  };

  const handleFindResearchGaps = async () => {
    if (selectedPapers.length === 0) {
      toast.error('Please select papers first');
      return;
    }

    toast.success('Finding research gaps...');
    router.push('/tools?tab=gaps&papers=' + encodeURIComponent(JSON.stringify(selectedPapers)));
  };

  const togglePaperSelection = (paper: any) => {
    setSelectedPapers(prev => {
      const isSelected = prev.some(p => p.id === paper.id);
      if (isSelected) {
        toast.success('Paper removed from selection');
        return prev.filter(p => p.id !== paper.id);
      } else {
        toast.success('Paper added to selection');
        return [...prev, paper];
      }
    });
  };

  const features = [
    {
      icon: <Sparkles className="w-8 h-8" />,
      title: 'AI Reading Assistant',
      description: 'Understand papers at your level: beginner to expert mode with intelligent explanations.',
      color: 'bg-blue-500',
    },
    {
      icon: <FileText className="w-8 h-8" />,
      title: 'Literature Review Generator',
      description: 'Compare papers, identify themes, and generate structured reviews automatically.',
      color: 'bg-purple-500',
    },
    {
      icon: <Lightbulb className="w-8 h-8" />,
      title: 'Research Gap Finder',
      description: 'Discover underexplored topics, contradictions, and opportunities in your field.',
      color: 'bg-yellow-500',
    },
    {
      icon: <Network className="w-8 h-8" />,
      title: 'Knowledge Graph',
      description: 'Visualize connections between papers, authors, concepts, and methodologies.',
      color: 'bg-green-500',
    },
    {
      icon: <BookOpen className="w-8 h-8" />,
      title: 'Study Mode',
      description: 'Generate flashcards, quizzes, and concept maps to master research papers.',
      color: 'bg-pink-500',
    },
    {
      icon: <MessageSquare className="w-8 h-8" />,
      title: 'AI Research Mentor',
      description: 'Ask questions about papers and get expert guidance on your research journey.',
      color: 'bg-indigo-500',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 dark:from-slate-900 dark:via-slate-900 dark:to-slate-800">
      {/* Navigation */}
      <nav className="border-b border-slate-200 dark:border-slate-700 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold gradient-text">ResearchMind</h1>
                <p className="text-xs text-slate-600 dark:text-slate-400">AI-Powered Research Assistant</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="sm" onClick={() => router.push('/features')}>
                Features
              </Button>
              <Button variant="ghost" size="sm" onClick={() => router.push('/tools')}>
                Tools
              </Button>
              {user ? (
                <>
                  <Button variant="ghost" size="sm" onClick={() => router.push('/dashboard')}>
                    Dashboard
                  </Button>
                  <div className="relative group">
                    <Button variant="ghost" size="sm" onClick={() => router.push('/profile')}>
                      <User className="w-5 h-5" />
                    </Button>
                    <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none group-hover:pointer-events-auto">
                      <div className="p-3">
                        <p className="text-sm font-medium text-slate-900 dark:text-slate-100">{user.name}</p>
                        <p className="text-xs text-slate-600 dark:text-slate-400">{user.email}</p>
                      </div>
                      <div className="border-t border-slate-200 dark:border-slate-700 p-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="w-full justify-start text-sm text-red-600 hover:text-red-700"
                          onClick={() => logout()}
                        >
                          <LogOut className="w-4 h-4 mr-2" />
                          Sign Out
                        </Button>
                      </div>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <Button variant="ghost" size="sm" onClick={() => router.push('/auth/login')}>
                    Sign In
                  </Button>
                  <Button size="sm" onClick={() => router.push('/auth/register')}>
                    Get Started
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeView === 'hero' && (
          <>
            {/* Hero Section */}
            <div className="text-center py-16 animate-fade-in">
              <h2 className="text-5xl font-bold text-slate-900 dark:text-slate-100 mb-4">
                {user ? `Welcome, ${user.name}!` : 'Understand Research,'}
                <br />
                <span className="gradient-text">{user ? 'Ready to Continue?' : "Don't Just Read It"}</span>
              </h2>
              <p className="text-xl text-slate-600 dark:text-slate-400 mb-8 max-w-2xl mx-auto">
                {user 
                  ? 'Continue your research journey with AI-powered tools.' 
                  : 'ResearchMind helps students and researchers comprehend scientific literature with AI-powered explanations, literature reviews, and intelligent insights.'}
              </p>

              {/* Search Bar */}
              <div className="max-w-3xl mx-auto mb-12">
                <SearchBar onSearch={handleSearch} isLoading={isSearching} />
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 max-w-4xl mx-auto mb-16">
                <Card className="text-center">
                  <CardContent className="py-6">
                    <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-1">
                      200M+
                    </div>
                    <div className="text-sm text-slate-600 dark:text-slate-400">
                      Research Papers
                    </div>
                  </CardContent>
                </Card>
                <Card className="text-center">
                  <CardContent className="py-6">
                    <div className="text-3xl font-bold text-purple-600 dark:text-purple-400 mb-1">
                      AI-Powered
                    </div>
                    <div className="text-sm text-slate-600 dark:text-slate-400">
                      Explanations
                    </div>
                  </CardContent>
                </Card>
                <Card className="text-center">
                  <CardContent className="py-6">
                    <div className="text-3xl font-bold text-green-600 dark:text-green-400 mb-1">
                      5+ Sources
                    </div>
                    <div className="text-sm text-slate-600 dark:text-slate-400">
                      Academic APIs
                    </div>
                  </CardContent>
                </Card>
                <Card className="text-center">
                  <CardContent className="py-6">
                    <div className="text-3xl font-bold text-pink-600 dark:text-pink-400 mb-1">
                      Smart Tools
                    </div>
                    <div className="text-sm text-slate-600 dark:text-slate-400">
                      Research Features
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Features Grid */}
            <div className="mb-16">
              <h3 className="text-3xl font-bold text-slate-900 dark:text-slate-100 text-center mb-8">
                Powerful Research Tools
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {features.map((feature, idx) => (
                  <Card key={idx} hover>
                    <CardContent className="p-6">
                      <div className={`w-12 h-12 ${feature.color} rounded-lg flex items-center justify-center text-white mb-4`}>
                        {feature.icon}
                      </div>
                      <h4 className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-2">
                        {feature.title}
                      </h4>
                      <p className="text-sm text-slate-600 dark:text-slate-400">
                        {feature.description}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* How It Works */}
            <div className="bg-white dark:bg-slate-800 rounded-2xl p-8 border border-slate-200 dark:border-slate-700">
              <h3 className="text-3xl font-bold text-slate-900 dark:text-slate-100 text-center mb-8">
                How It Works
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Search className="w-8 h-8 text-blue-600 dark:text-blue-400" />
                  </div>
                  <h4 className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-2">
                    1. Search Papers
                  </h4>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    Search across multiple academic databases with advanced filters
                  </p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Sparkles className="w-8 h-8 text-purple-600 dark:text-purple-400" />
                  </div>
                  <h4 className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-2">
                    2. AI Analysis
                  </h4>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    Get intelligent explanations tailored to your knowledge level
                  </p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4">
                    <TrendingUp className="w-8 h-8 text-green-600 dark:text-green-400" />
                  </div>
                  <h4 className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-2">
                    3. Learn & Research
                  </h4>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    Build knowledge, find gaps, and advance your research
                  </p>
                </div>
              </div>
            </div>
          </>
        )}

        {activeView === 'search' && (
          <div className="animate-fade-in">
            <div className="mb-6">
              <SearchBar onSearch={handleSearch} isLoading={isSearching} />
            </div>

            {isSearching && (
              <div className="text-center py-12">
                <div className="inline-block w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mb-4"></div>
                <p className="text-slate-600 dark:text-slate-400">Searching across academic databases...</p>
              </div>
            )}

            {!isSearching && papers.length > 0 && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h3 className="text-xl font-semibold text-slate-900 dark:text-slate-100">
                      Found {papers.length} papers
                    </h3>
                    {selectedPapers.length > 0 && (
                      <p className="text-sm text-slate-600 dark:text-slate-400">
                        {selectedPapers.length} selected
                      </p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={handleGenerateLiteratureReview}
                      disabled={selectedPapers.length < 2}
                    >
                      <FileText className="w-4 h-4 mr-2" />
                      Generate Literature Review
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={handleFindResearchGaps}
                      disabled={selectedPapers.length === 0}
                    >
                      <Lightbulb className="w-4 h-4 mr-2" />
                      Find Research Gaps
                    </Button>
                  </div>
                </div>
                <div className="grid grid-cols-1 gap-6">
                  {papers.map((paper) => (
                    <div key={paper.id} className="relative">
                      <input
                        type="checkbox"
                        checked={selectedPapers.some(p => p.id === paper.id)}
                        onChange={() => togglePaperSelection(paper)}
                        className="absolute top-4 left-4 z-10 w-5 h-5 text-blue-600 border-slate-300 rounded focus:ring-blue-500 cursor-pointer"
                      />
                      <div className="pl-12">
                        <PaperCard
                          paper={paper}
                          onSelect={handlePaperSelect}
                          onExplain={handlePaperSelect}
                          onCite={handlePaperSelect}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {!isSearching && papers.length === 0 && (
              <div className="text-center py-12">
                <Search className="w-16 h-16 text-slate-300 dark:text-slate-600 mx-auto mb-4" />
                <p className="text-slate-600 dark:text-slate-400">
                  No papers found. Try adjusting your search query or filters.
                </p>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Paper Modal */}
      {showModal && selectedPaper && (
        <PaperModal
          paper={selectedPaper}
          onClose={() => {
            setShowModal(false);
            setSelectedPaper(null);
          }}
        />
      )}

      {/* Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Brain className="w-6 h-6 text-blue-600" />
                <span className="font-bold text-slate-900 dark:text-slate-100">ResearchMind</span>
              </div>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                AI-powered research assistant for students and researchers worldwide.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900 dark:text-slate-100 mb-3">Features</h4>
              <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-400">
                <li>Paper Search</li>
                <li>AI Explanations</li>
                <li>Literature Reviews</li>
                <li>Research Gaps</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900 dark:text-slate-100 mb-3">Resources</h4>
              <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-400">
                <li>Documentation</li>
                <li>API Reference</li>
                <li>Blog</li>
                <li>Tutorials</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900 dark:text-slate-100 mb-3">Data Sources</h4>
              <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-400">
                <li>Semantic Scholar</li>
                <li>OpenAlex</li>
                <li>arXiv</li>
                <li>PubMed</li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-slate-200 dark:border-slate-700 text-center text-sm text-slate-600 dark:text-slate-400">
            © 2024 ResearchMind. Built with Next.js, OpenAI, and academic data APIs.
          </div>
        </div>
      </footer>
    </div>
  );
}
