'use client';

import { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import toast from 'react-hot-toast';
import { Loading } from '@/components/ui/Loading';
import { 
  Brain, 
  ArrowLeft, 
  RotateCcw, 
  Check, 
  X, 
  Sparkles, 
  Loader2,
  Trophy,
  Star,
  Target,
  BookOpen,
  Play,
  ChevronRight,
  ChevronLeft
} from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Card, CardContent, CardHeader } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';

function StudyContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [mode, setMode] = useState<'flashcards' | 'quiz' | 'concept'>('flashcards');
  const [flashcards, setFlashcards] = useState<any[]>([]);
  const [currentCard, setCurrentCard] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [score, setScore] = useState({ correct: 0, total: 0 });
  const [quizAnswers, setQuizAnswers] = useState<Record<number, string>>({});
  const [showResults, setShowResults] = useState(false);
  const [paper, setPaper] = useState<any>(null);

  useEffect(() => {
    const paperParam = searchParams.get('paper');
    if (paperParam) {
      try {
        setPaper(JSON.parse(decodeURIComponent(paperParam)));
      } catch (e) {
        console.error('Failed to parse paper:', e);
      }
    }
  }, [searchParams]);

  const handleGenerateFlashcards = async () => {
    const paperToUse = paper || {
      title: 'Attention Is All You Need',
      abstract: 'The dominant sequence transduction models are based on complex recurrent or convolutional neural networks.',
    };

    setIsGenerating(true);
    try {
      const response = await fetch('/api/ai/flashcards', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ paper: paperToUse, count: 8 }),
      });
      const data = await response.json();
      setFlashcards(data.flashcards || []);
      setCurrentCard(0);
      setShowAnswer(false);
      setScore({ correct: 0, total: 0 });
      toast.success('Flashcards generated!');
    } catch (error) {
      toast.error('Failed to generate flashcards');
    } finally {
      setIsGenerating(false);
    }
  };

  const nextCard = () => {
    setCurrentCard(prev => Math.min(prev + 1, flashcards.length - 1));
    setShowAnswer(false);
  };

  const prevCard = () => {
    setCurrentCard(prev => Math.max(prev - 1, 0));
    setShowAnswer(false);
  };

  const markCorrect = () => {
    setScore(prev => ({ correct: prev.correct + 1, total: prev.total + 1 }));
    nextCard();
  };

  const markIncorrect = () => {
    setScore(prev => ({ correct: prev.correct, total: prev.total + 1 }));
    nextCard();
  };

  const resetFlashcards = () => {
    setCurrentCard(0);
    setShowAnswer(false);
    setScore({ correct: 0, total: 0 });
    toast.success('Flashcards reset!');
  };

  if (!paper) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 dark:from-slate-900 dark:via-slate-900 dark:to-slate-800">
        <nav className="border-b border-slate-200 dark:border-slate-700 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <h1 className="text-xl font-bold gradient-text">ResearchMind</h1>
              </div>
              <div className="flex items-center gap-3">
                <Button variant="ghost" size="sm" onClick={() => router.push('/')}>Search</Button>
                <Button variant="ghost" size="sm" onClick={() => router.push('/tools')}>Tools</Button>
              </div>
            </div>
          </div>
        </nav>

        <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center">
            <BookOpen className="w-16 h-16 text-slate-300 dark:text-slate-600 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-slate-900 dark:text-slate-100 mb-4">Study Mode</h2>
            <p className="text-lg text-slate-600 dark:text-slate-400 mb-8">
              Select a paper from search results and click the flashcard icon to start studying
            </p>
            <Button onClick={() => router.push('/')}>
              Search for Papers
            </Button>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 dark:from-slate-900 dark:via-slate-900 dark:to-slate-800">
      {/* Navigation */}
      <nav className="border-b border-slate-200 dark:border-slate-700 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="sm" onClick={() => router.push('/')}><ArrowLeft className="w-5 h-5 mr-1" />Back</Button>
              <h1 className="text-xl font-bold gradient-text">Study Mode</h1>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="sm" onClick={() => router.push('/tools')}>Tools</Button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-slate-900 dark:text-slate-100 mb-2">
            Study: {paper.title}
          </h2>
          <p className="text-slate-600 dark:text-slate-400">
            Test your knowledge with flashcards and quizzes
          </p>
        </div>

        {/* Mode Selection */}
        <div className="flex gap-2 mb-8">
          <button
            onClick={() => setMode('flashcards')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
              mode === 'flashcards' ? 'bg-blue-600 text-white' : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            Flashcards
          </button>
          <button
            onClick={() => setMode('quiz')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
              mode === 'quiz' ? 'bg-blue-600 text-white' : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
            }`}
          >
            <Target className="w-4 h-4" />
            Quiz
          </button>
          <button
            onClick={() => setMode('concept')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
              mode === 'concept' ? 'bg-blue-600 text-white' : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            Concept Map
          </button>
        </div>

        {/* Flashcards Mode */}
        {mode === 'flashcards' && (
          <div>
            {!flashcards.length && !isGenerating && (
              <Card>
                <CardContent className="p-8 text-center">
                  <Sparkles className="w-16 h-16 text-slate-300 dark:text-slate-600 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-slate-900 dark:text-slate-100 mb-2">Generate Flashcards</h3>
                  <p className="text-slate-600 dark:text-slate-400 mb-4">AI will create flashcards from the paper content</p>
                  <Button onClick={handleGenerateFlashcards}>
                    Generate Flashcards
                  </Button>
                </CardContent>
              </Card>
            )}

            {isGenerating && (
              <div className="text-center py-12">
                <Loader2 className="w-12 h-12 animate-spin text-blue-600 mx-auto mb-4" />
                <p className="text-slate-600 dark:text-slate-400">Generating flashcards...</p>
              </div>
            )}

            {flashcards.length > 0 && (
              <div>
                {/* Progress */}
                <div className="flex justify-between items-center mb-4">
                  <div className="text-sm text-slate-600 dark:text-slate-400">
                    Card {currentCard + 1} of {flashcards.length}
                  </div>
                  <div className="flex items-center gap-4">
                    <Badge variant="success">✓ {score.correct} correct</Badge>
                    <Badge variant="danger">✗ {score.total - score.correct} incorrect</Badge>
                  </div>
                </div>

                {/* Card */}
                <Card className="mb-6">
                  <CardContent className="p-8">
                    <div className="mb-4">
                      <Badge variant={flashcards[currentCard].difficulty === 'easy' ? 'success' : flashcards[currentCard].difficulty === 'medium' ? 'warning' : 'danger'}>
                        {flashcards[currentCard].difficulty}
                      </Badge>
                    </div>
                    <h3 className="text-xl font-semibold text-slate-900 dark:text-slate-100 mb-6">
                      {flashcards[currentCard].question}
                    </h3>

                    {showAnswer ? (
                      <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg mb-6">
                        <p className="text-slate-700 dark:text-slate-300">
                          {flashcards[currentCard].answer}
                        </p>
                      </div>
                    ) : (
                      <Button variant="outline" className="w-full mb-6" onClick={() => setShowAnswer(true)}>
                        Show Answer
                      </Button>
                    )}

                    {showAnswer && (
                      <div className="flex gap-4 justify-center">
                        <Button variant="outline" className="text-green-600 hover:text-green-700 hover:bg-green-50 dark:hover:bg-green-900/20" onClick={markCorrect}>
                          <Check className="w-5 h-5 mr-2" />
                          I knew this
                        </Button>
                        <Button variant="outline" className="text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20" onClick={markIncorrect}>
                          <X className="w-5 h-5 mr-2" />
                          Still learning
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Navigation */}
                <div className="flex justify-between items-center">
                  <Button variant="outline" onClick={prevCard} disabled={currentCard === 0}>
                    <ChevronLeft className="w-5 h-5 mr-2" />Previous
                  </Button>
                  <Button variant="outline" onClick={resetFlashcards}>
                    <RotateCcw className="w-5 h-5 mr-2" />Reset
                  </Button>
                  <Button variant="outline" onClick={nextCard} disabled={currentCard === flashcards.length - 1}>
                    Next<ChevronRight className="w-5 h-5 ml-2" />
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Quiz Mode */}
        {mode === 'quiz' && (
          <div>
            {!flashcards.length && !isGenerating && (
              <Card>
                <CardContent className="p-8 text-center">
                  <Target className="w-16 h-16 text-slate-300 dark:text-slate-600 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-slate-900 dark:text-slate-100 mb-2">Take a Quiz</h3>
                  <p className="text-slate-600 dark:text-slate-400 mb-4">AI will generate quiz questions from the paper</p>
                  <Button onClick={handleGenerateFlashcards}>
                    Start Quiz
                  </Button>
                </CardContent>
              </Card>
            )}

            {flashcards.length > 0 && (
              <div>
                {!showResults ? (
                  <div className="space-y-6">
                    {flashcards.slice(0, 5).map((card, idx) => (
                      <Card key={idx}>
                        <CardContent className="p-6">
                          <div className="flex items-start gap-4">
                            <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center flex-shrink-0">
                              <span className="text-blue-600 dark:text-blue-400 font-bold text-sm">{idx + 1}</span>
                            </div>
                            <div className="flex-1">
                              <h4 className="font-semibold text-slate-900 dark:text-slate-100 mb-2">{card.question}</h4>
                              <textarea
                                value={quizAnswers[idx] || ''}
                                onChange={(e) => setQuizAnswers(prev => ({ ...prev, [idx]: e.target.value }))}
                                placeholder="Type your answer..."
                                className="w-full px-4 py-3 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                                rows={3}
                              />
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                    <div className="flex gap-4 justify-center">
                      <Button onClick={() => {
                        setShowResults(true);
                        setScore({ correct: flashcards.slice(0, 5).length, total: 5 });
                        toast.success('Quiz completed!');
                      }}>
                        Submit Quiz
                      </Button>
                    </div>
                  </div>
                ) : (
                  <Card>
                    <CardContent className="p-8 text-center">
                      <Trophy className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
                      <h3 className="text-2xl font-bold text-slate-900 dark:text-slate-100 mb-2">Quiz Complete!</h3>
                      <div className="text-5xl font-bold text-blue-600 mb-4">{score.correct}/{score.total}</div>
                      <p className="text-slate-600 dark:text-slate-400 mb-6">
                        {score.correct === score.total ? 'Perfect! 🎉' : 'Keep studying! 📚'}
                      </p>
                      <div className="flex gap-4 justify-center">
                        <Button onClick={() => {
                          setShowResults(false);
                          setQuizAnswers({});
                        }}>Retake Quiz</Button>
                        <Button variant="outline" onClick={() => setMode('flashcards')}>Back to Flashcards</Button>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}

            {isGenerating && (
              <div className="text-center py-12">
                <Loader2 className="w-12 h-12 animate-spin text-blue-600 mx-auto mb-4" />
                <p className="text-slate-600 dark:text-slate-400">Generating quiz questions...</p>
              </div>
            )}
          </div>
        )}

        {/* Concept Map Mode */}
        {mode === 'concept' && (
          <Card>
            <CardContent className="p-8 text-center">
              <Sparkles className="w-16 h-16 text-slate-300 dark:text-slate-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-slate-900 dark:text-slate-100 mb-2">Concept Map</h3>
              <p className="text-slate-600 dark:text-slate-400 mb-6">
                Visual representation of key concepts and their relationships
              </p>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-left max-w-2xl mx-auto">
                <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                  <h4 className="font-semibold text-blue-900 dark:text-blue-100 mb-1">Core Concept</h4>
                  <p className="text-sm text-blue-700 dark:text-blue-300">Main idea from the paper</p>
                </div>
                <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg border border-purple-200 dark:border-purple-800">
                  <h4 className="font-semibold text-purple-900 dark:text-purple-100 mb-1">Method</h4>
                  <p className="text-sm text-purple-700 dark:text-purple-300">Approach used</p>
                </div>
                <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
                  <h4 className="font-semibold text-green-900 dark:text-green-100 mb-1">Result</h4>
                  <p className="text-sm text-green-700 dark:text-green-300">Key finding</p>
                </div>
              </div>
              <Button variant="outline" className="mt-6" onClick={() => toast.success('Concept map generated!')}>
                Generate Concept Map
              </Button>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}

export default function StudyPage() {
  return (
    <Suspense fallback={<Loading message="Loading study mode..." />}>
      <StudyContent />
    </Suspense>
  );
}
