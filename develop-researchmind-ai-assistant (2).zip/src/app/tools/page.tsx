'use client';

import { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import toast from 'react-hot-toast';
import { Brain, FileText, Lightbulb, Network, MessageSquare, Table, Download, Copy, Save } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Card, CardContent, CardHeader } from '@/components/ui/Card';
import { ResearchChat } from '@/components/ResearchChat';
import { KnowledgeGraph } from '@/components/KnowledgeGraph';
import { ComparisonTable } from '@/components/ComparisonTable';
import { Loading } from '@/components/ui/Loading';

function ToolsContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [activeTool, setActiveTool] = useState<string>('chat');
  const [literatureReview, setLiteratureReview] = useState<any>(null);
  const [researchGaps, setResearchGaps] = useState<any[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [loadedPapers, setLoadedPapers] = useState<any[]>([]);

  useEffect(() => {
    const tab = searchParams.get('tab');
    const papersParam = searchParams.get('papers');
    
    if (tab) {
      setActiveTool(tab);
    }
    
    if (papersParam) {
      try {
        const papers = JSON.parse(decodeURIComponent(papersParam));
        setLoadedPapers(papers);
        
        // Auto-generate based on tab
        if (tab === 'literature' && papers.length >= 2) {
          handleGenerateLiteratureReview(papers);
        } else if (tab === 'gaps' && papers.length > 0) {
          handleFindResearchGaps(papers);
        }
      } catch (e) {
        console.error('Failed to parse papers:', e);
      }
    }
  }, [searchParams]);

  const samplePapers = [
    {
      title: 'Attention Is All You Need',
      abstract: 'The dominant sequence transduction models are based on complex recurrent or convolutional neural networks.',
      year: 2017,
      authors: [{ name: 'Vaswani et al.' }],
    },
    {
      title: 'BERT: Pre-training of Deep Bidirectional Transformers',
      abstract: 'We introduce a new language representation model called BERT.',
      year: 2018,
      authors: [{ name: 'Devlin et al.' }],
    },
  ];

  const comparisonData = [
    {
      paper: 'BERT',
      year: 2018,
      dataset: 'GLUE',
      model: 'Transformer Encoder',
      accuracy: 0.884,
      precision: 0.891,
      recall: 0.877,
      f1Score: 0.884,
      limitations: ['Requires large computational resources', 'Pre-training is expensive'],
    },
    {
      paper: 'GPT-3',
      year: 2020,
      dataset: 'WebText',
      model: 'Transformer Decoder',
      accuracy: 0.920,
      precision: 0.915,
      recall: 0.925,
      f1Score: 0.920,
      limitations: ['Very large model size', 'Potential for bias'],
    },
    {
      paper: 'T5',
      year: 2019,
      dataset: 'C4',
      model: 'Encoder-Decoder',
      accuracy: 0.898,
      precision: 0.902,
      recall: 0.894,
      f1Score: 0.898,
      limitations: ['Complex training procedure', 'Task-specific fine-tuning needed'],
    },
  ];

  const handleGenerateLiteratureReview = async (papersToUse?: any[]) => {
    const papers = papersToUse || loadedPapers.length > 0 ? loadedPapers : samplePapers;
    
    if (papers.length < 2) {
      toast.error('Please provide at least 2 papers');
      return;
    }
    
    setIsGenerating(true);
    try {
      const response = await fetch('/api/ai/literature-review', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          papers: papers,
          focusArea: 'Transformer architectures in NLP',
        }),
      });
      const data = await response.json();
      setLiteratureReview(data.review);
      toast.success('Literature review generated!');
    } catch (error) {
      console.error('Failed to generate literature review:', error);
      toast.error('Failed to generate literature review');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleFindResearchGaps = async (papersToUse?: any[]) => {
    const papers = papersToUse || loadedPapers.length > 0 ? loadedPapers : samplePapers;
    
    if (papers.length === 0) {
      toast.error('Please provide papers to analyze');
      return;
    }
    
    setIsGenerating(true);
    try {
      const response = await fetch('/api/ai/research-gaps', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ papers: papers }),
      });
      const data = await response.json();
      setResearchGaps(data.gaps || []);
      toast.success('Research gaps identified!');
    } catch (error) {
      console.error('Failed to find research gaps:', error);
      toast.error('Failed to find research gaps');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleExportPDF = () => {
    toast.success('Export to PDF feature coming soon!');
  };

  const handleCopyToClipboard = (content: string) => {
    navigator.clipboard.writeText(content);
    toast.success('Copied to clipboard!');
  };

  const handleSaveToProject = () => {
    toast.success('Save to project feature coming soon!');
  };

  const tools = [
    { id: 'chat', name: 'AI Research Mentor', icon: MessageSquare },
    { id: 'literature', name: 'Literature Review', icon: FileText },
    { id: 'gaps', name: 'Research Gaps', icon: Lightbulb },
    { id: 'graph', name: 'Knowledge Graph', icon: Network },
    { id: 'comparison', name: 'Comparison Table', icon: Table },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 dark:from-slate-900 dark:via-slate-900 dark:to-slate-800">
      {/* Navigation */}
      <nav className="border-b border-slate-200 dark:border-slate-700 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold gradient-text">ResearchMind</h1>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="sm" onClick={() => router.push('/')}>
                Search
              </Button>
              <Button variant="ghost" size="sm" onClick={() => router.push('/dashboard')}>
                Dashboard
              </Button>
              <Button variant="ghost" size="sm">Tools</Button>
              <Button variant="ghost" size="sm" onClick={() => router.push('/features')}>
                Features
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-slate-900 dark:text-slate-100 mb-2">
            Research Tools
          </h2>
          <p className="text-slate-600 dark:text-slate-400">
            Advanced AI-powered tools to analyze, compare, and understand research papers
          </p>
        </div>

        {/* Tool Selection */}
        <div className="flex flex-wrap gap-2 mb-8">
          {tools.map((tool) => {
            const Icon = tool.icon;
            return (
              <button
                key={tool.id}
                onClick={() => setActiveTool(tool.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                  activeTool === tool.id
                    ? 'bg-blue-600 text-white'
                    : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tool.name}
              </button>
            );
          })}
        </div>

        {/* Tool Content */}
        <div className="animate-fade-in">
          {activeTool === 'chat' && (
            <ResearchChat papers={samplePapers} />
          )}

          {activeTool === 'literature' && (
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="text-xl font-semibold text-slate-900 dark:text-slate-100">
                      Literature Review Generator
                    </h3>
                    <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                      Automatically generate comprehensive literature reviews from selected papers
                    </p>
                  </div>
                  <Button onClick={() => handleGenerateLiteratureReview()} disabled={isGenerating}>
                    {isGenerating ? 'Generating...' : 'Generate Review'}
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {literatureReview ? (
                  <div className="prose dark:prose-invert max-w-none">
                    <div className="mb-6">
                      <h4 className="text-lg font-semibold mb-2">Introduction</h4>
                      <p className="text-slate-700 dark:text-slate-300 whitespace-pre-wrap">
                        {literatureReview.introduction}
                      </p>
                    </div>

                    {literatureReview.sections?.map((section: any, idx: number) => (
                      <div key={idx} className="mb-6">
                        <h4 className="text-lg font-semibold mb-2">{section.title}</h4>
                        <p className="text-slate-700 dark:text-slate-300 whitespace-pre-wrap">
                          {section.content}
                        </p>
                      </div>
                    ))}

                    <div className="mb-6">
                      <h4 className="text-lg font-semibold mb-2">Conclusion</h4>
                      <p className="text-slate-700 dark:text-slate-300 whitespace-pre-wrap">
                        {literatureReview.conclusion}
                      </p>
                    </div>

                    <div className="flex gap-2 mt-6">
                      <Button variant="outline" onClick={handleExportPDF}>
                        <Download className="w-4 h-4 mr-2" />
                        Export to PDF
                      </Button>
                      <Button variant="outline" onClick={() => {
                        const content = `${literatureReview.introduction}\n\n${literatureReview.sections?.map((s: any) => `${s.title}\n${s.content}`).join('\n\n')}\n\n${literatureReview.conclusion}`;
                        handleCopyToClipboard(content);
                      }}>
                        <Copy className="w-4 h-4 mr-2" />
                        Copy to Clipboard
                      </Button>
                      <Button variant="outline" onClick={handleSaveToProject}>
                        <Save className="w-4 h-4 mr-2" />
                        Save to Project
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <FileText className="w-16 h-16 text-slate-300 dark:text-slate-600 mx-auto mb-4" />
                    <p className="text-slate-600 dark:text-slate-400">
                      Click "Generate Review" to create a literature review from your selected papers
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {activeTool === 'gaps' && (
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="text-xl font-semibold text-slate-900 dark:text-slate-100">
                      Research Gap Finder
                    </h3>
                    <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                      Identify underexplored areas, contradictions, and opportunities in your field
                    </p>
                  </div>
                  <Button onClick={() => handleFindResearchGaps()} disabled={isGenerating}>
                    {isGenerating ? 'Analyzing...' : 'Find Gaps'}
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {researchGaps.length > 0 ? (
                  <div className="space-y-4">
                    {researchGaps.map((gap, idx) => (
                      <div
                        key={idx}
                        className="p-4 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                      >
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="font-semibold text-slate-900 dark:text-slate-100">
                            {gap.title}
                          </h4>
                          <div className="flex gap-2">
                            <span className={`px-2 py-1 rounded text-xs font-medium ${
                              gap.category === 'underexplored' ? 'bg-blue-100 text-blue-700' :
                              gap.category === 'contradictory' ? 'bg-red-100 text-red-700' :
                              gap.category === 'limitation' ? 'bg-yellow-100 text-yellow-700' :
                              'bg-green-100 text-green-700'
                            }`}>
                              {gap.category}
                            </span>
                            <span className={`px-2 py-1 rounded text-xs font-medium ${
                              gap.severity === 'high' ? 'bg-red-100 text-red-700' :
                              gap.severity === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                              'bg-green-100 text-green-700'
                            }`}>
                              {gap.severity}
                            </span>
                          </div>
                        </div>
                        <p className="text-sm text-slate-700 dark:text-slate-300">
                          {gap.description}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Lightbulb className="w-16 h-16 text-slate-300 dark:text-slate-600 mx-auto mb-4" />
                    <p className="text-slate-600 dark:text-slate-400">
                      Click "Find Gaps" to discover research opportunities in your selected papers
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {activeTool === 'graph' && (
            <KnowledgeGraph papers={samplePapers} />
          )}

          {activeTool === 'comparison' && (
            <ComparisonTable data={comparisonData} />
          )}
        </div>
      </main>
    </div>
  );
}

export default function ToolsPage() {
  return (
    <Suspense fallback={<Loading message="Loading tools..." />}>
      <ToolsContent />
    </Suspense>
  );
}
