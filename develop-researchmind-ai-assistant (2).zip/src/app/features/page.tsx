'use client';

import { useRouter } from 'next/navigation';
import toast from 'react-hot-toast';
import { 
  Brain, 
  Search, 
  Sparkles, 
  FileText, 
  Lightbulb, 
  Network, 
  MessageSquare,
  BookOpen,
  Table,
  Users,
  TrendingUp,
  Target,
  Zap,
  Shield,
  Globe,
  Download
} from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Card, CardContent } from '@/components/ui/Card';

export default function FeaturesPage() {
  const router = useRouter();
  
  const features = [
    {
      icon: Search,
      title: 'Multi-Source Paper Search',
      description: 'Search across Semantic Scholar, OpenAlex, arXiv, and more with advanced filters for year, citations, field, and open-access status.',
      color: 'bg-blue-500',
      benefits: ['200M+ papers', 'Real-time results', 'Smart recommendations'],
    },
    {
      icon: Sparkles,
      title: 'AI Reading Assistant',
      description: 'Understand papers at your level with AI explanations from beginner to expert mode. Get section-by-section breakdowns and key insights.',
      color: 'bg-purple-500',
      benefits: ['4 knowledge levels', 'Key contributions', 'Limitations analysis'],
    },
    {
      icon: FileText,
      title: 'Literature Review Generator',
      description: 'Automatically generate comprehensive literature reviews by analyzing multiple papers, identifying themes, and discovering research gaps.',
      color: 'bg-green-500',
      benefits: ['Auto-generation', 'Theme grouping', 'Gap identification'],
    },
    {
      icon: Lightbulb,
      title: 'Research Gap Finder',
      description: 'AI analyzes your paper collection to identify underexplored topics, contradictory findings, and future research opportunities.',
      color: 'bg-yellow-500',
      benefits: ['Automated analysis', 'Severity ranking', 'Actionable insights'],
    },
    {
      icon: MessageSquare,
      title: 'AI Research Mentor',
      description: 'Chat with an AI that understands your papers. Ask questions, get explanations, and receive guidance on your research journey.',
      color: 'bg-pink-500',
      benefits: ['Context-aware', 'Unlimited questions', 'Chat history'],
    },
    {
      icon: Network,
      title: 'Knowledge Graph',
      description: 'Visualize connections between papers, authors, concepts, datasets, and methodologies in an interactive graph.',
      color: 'bg-indigo-500',
      benefits: ['Visual exploration', 'Citation networks', 'Community detection'],
    },
    {
      icon: Table,
      title: 'Experiment Comparison',
      description: 'Compare papers side-by-side with metrics like accuracy, precision, recall, F1 score, datasets, and limitations.',
      color: 'bg-red-500',
      benefits: ['Side-by-side view', 'Metric comparison', 'Export data'],
    },
    {
      icon: BookOpen,
      title: 'Study Mode',
      description: 'Generate AI-powered flashcards, quizzes, and concept maps. Track your reading progress and master papers faster.',
      color: 'bg-teal-500',
      benefits: ['Auto flashcards', 'Progress tracking', 'Spaced repetition'],
    },
    {
      icon: Target,
      title: 'Citation Assistant',
      description: 'Generate citations in APA, MLA, IEEE, Chicago, and BibTeX formats. One-click copy and reference management.',
      color: 'bg-orange-500',
      benefits: ['5+ formats', 'Instant generation', 'Copy to clipboard'],
    },
    {
      icon: TrendingUp,
      title: 'Analytics Dashboard',
      description: 'Track papers read, reading streaks, time spent, and favorite topics. Get AI recommendations for what to read next.',
      color: 'bg-cyan-500',
      benefits: ['Reading stats', 'Streak tracking', 'AI recommendations'],
    },
    {
      icon: Users,
      title: 'Collaboration',
      description: 'Share projects, synchronize notes and highlights, and collaborate with your research team in real-time.',
      color: 'bg-violet-500',
      benefits: ['Shared projects', 'Team notes', 'Sync highlights'],
    },
    {
      icon: Download,
      title: 'Export Everything',
      description: 'Export literature reviews, annotations, citations, and data to PDF, Word, Markdown, BibTeX, and more.',
      color: 'bg-emerald-500',
      benefits: ['Multiple formats', 'One-click export', 'Integration ready'],
    },
  ];

  const whyDifferent = [
    {
      icon: Zap,
      title: 'Understand, Don\'t Just Summarize',
      description: 'ResearchMind goes beyond summaries to provide deep, contextual understanding at your knowledge level.',
    },
    {
      icon: Shield,
      title: 'Privacy-First',
      description: 'Your research data stays private. We don\'t sell your data or track your reading habits.',
    },
    {
      icon: Globe,
      title: 'Open Access Focus',
      description: 'We prioritize open-access papers and free academic resources to democratize research.',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 dark:from-slate-900 dark:via-slate-900 dark:to-slate-800">
      {/* Navigation */}
      <nav className="border-b border-slate-200 dark:border-slate-700 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold gradient-text">ResearchMind</h1>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="sm" onClick={() => router.push('/')}>
                Home
              </Button>
              <Button variant="ghost" size="sm">Features</Button>
              <Button variant="ghost" size="sm" onClick={() => router.push('/tools')}>
                Tools
              </Button>
              <Button variant="ghost" size="sm" onClick={() => router.push('/dashboard')}>
                Dashboard
              </Button>
              <Button size="sm" onClick={() => {
                router.push('/');
                toast.success('Start by searching for papers!');
              }}>
                Get Started
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Hero */}
        <div className="text-center mb-16">
          <h2 className="text-5xl font-bold text-slate-900 dark:text-slate-100 mb-4">
            Powerful Research Tools
          </h2>
          <p className="text-xl text-slate-600 dark:text-slate-400 max-w-3xl mx-auto">
            Everything you need to search, understand, analyze, and write research papers — all in one place.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {features.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <Card key={idx} hover className="h-full">
                <CardContent className="p-6">
                  <div className={`w-12 h-12 ${feature.color} rounded-lg flex items-center justify-center text-white mb-4`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                    {feature.description}
                  </p>
                  <ul className="space-y-1">
                    {feature.benefits.map((benefit, bidx) => (
                      <li key={bidx} className="text-xs text-slate-700 dark:text-slate-300 flex items-center gap-2">
                        <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span>
                        {benefit}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Why Different */}
        <div className="mb-16">
          <h3 className="text-3xl font-bold text-slate-900 dark:text-slate-100 text-center mb-8">
            Why ResearchMind is Different
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {whyDifferent.map((item, idx) => {
              const Icon = item.icon;
              return (
                <Card key={idx}>
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white mb-4 mx-auto">
                      <Icon className="w-8 h-8" />
                    </div>
                    <h4 className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-2">
                      {item.title}
                    </h4>
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                      {item.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-12 text-white">
          <h3 className="text-3xl font-bold mb-4">
            Ready to Transform Your Research?
          </h3>
          <p className="text-lg mb-8 opacity-90">
            Join thousands of researchers and students who use ResearchMind to understand, analyze, and write better research.
          </p>
          <div className="flex gap-4 justify-center">
            <Button size="lg" variant="secondary" onClick={() => {
              router.push('/');
              toast.success('Welcome! Start by searching for papers.');
            }}>
              Start Free Trial
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10" onClick={() => {
              toast.success('Demo video coming soon!');
            }}>
              Watch Demo
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
