import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || 'sk-dummy-key-for-build',
});

function checkApiKey() {
  if (!process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY === 'sk-dummy-key-for-build') {
    throw new Error('OpenAI API key is not configured. Please set OPENAI_API_KEY environment variable.');
  }
}

export async function explainPaper(
  paper: {
    title: string;
    abstract: string | null;
    authors?: any;
  },
  level: 'beginner' | 'undergraduate' | 'graduate' | 'expert' = 'undergraduate'
): Promise<string> {
  checkApiKey();
  
  const levelDescriptions = {
    beginner: 'a high school student with no technical background',
    undergraduate: 'an undergraduate student with basic knowledge of the field',
    graduate: 'a graduate student familiar with advanced concepts',
    expert: 'an expert researcher in the field',
  };

  const prompt = `You are an expert research assistant. Explain the following research paper to ${levelDescriptions[level]}.

Title: ${paper.title}

Abstract: ${paper.abstract || 'No abstract available'}

Please provide:
1. A clear explanation of what the paper is about
2. The main problem it addresses
3. The key contributions and findings
4. Why this work is important
5. Any limitations or assumptions

Keep the explanation appropriate for the target audience level.`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [
      {
        role: 'system',
        content: 'You are a helpful research assistant that explains scientific papers clearly and accurately.',
      },
      {
        role: 'user',
        content: prompt,
      },
    ],
    temperature: 0.7,
    max_tokens: 1500,
  });

  return response.choices[0]?.message?.content || 'Unable to generate explanation.';
}

export async function generateLiteratureReview(
  papers: Array<{
    title: string;
    abstract: string | null;
    year?: number | null;
    authors?: any;
  }>,
  focusArea?: string
): Promise<{
  introduction: string;
  sections: Array<{ title: string; content: string }>;
  conclusion: string;
}> {
  checkApiKey();
  
  const papersText = papers.map((p, i) => 
    `${i + 1}. ${p.title} (${p.year || 'N/A'})\n   ${p.abstract || 'No abstract available'}`
  ).join('\n\n');

  const prompt = `You are an expert academic writer. Generate a comprehensive literature review for the following papers${focusArea ? ` focusing on: ${focusArea}` : ''}.

Papers:
${papersText}

Please provide:
1. An introduction that sets the context
2. Thematic sections grouping related papers by:
   - Methodology
   - Research direction
   - Key findings
3. Identify:
   - Common themes and agreements
   - Disagreements or contradictory findings
   - Research gaps
4. A conclusion summarizing the state of the field

Format the response as a structured JSON with: { introduction, sections: [{ title, content }], conclusion }`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [
      {
        role: 'system',
        content: 'You are an expert academic writer specializing in literature reviews. Always respond with valid JSON.',
      },
      {
        role: 'user',
        content: prompt,
      },
    ],
    temperature: 0.7,
    max_tokens: 2500,
    response_format: { type: 'json_object' },
  });

  const content = response.choices[0]?.message?.content;
  if (!content) {
    throw new Error('Failed to generate literature review');
  }

  return JSON.parse(content);
}

export async function findResearchGaps(
  papers: Array<{
    title: string;
    abstract: string | null;
  }>
): Promise<Array<{
  title: string;
  description: string;
  category: string;
  severity: string;
}>> {
  checkApiKey();
  
  const papersText = papers.map((p, i) => 
    `${i + 1}. ${p.title}\n   ${p.abstract || 'No abstract available'}`
  ).join('\n\n');

  const prompt = `Analyze the following research papers and identify research gaps. Focus on:

1. Underexplored topics or areas that lack sufficient research
2. Contradictory findings that need resolution
3. Common limitations mentioned across papers
4. Suggested future research directions

Papers:
${papersText}

Provide a JSON array of gaps with: title, description, category (underexplored/contradictory/limitation/future-work), severity (low/medium/high)`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [
      {
        role: 'system',
        content: 'You are an expert research analyst. Always respond with valid JSON.',
      },
      {
        role: 'user',
        content: prompt,
      },
    ],
    temperature: 0.7,
    max_tokens: 2000,
    response_format: { type: 'json_object' },
  });

  const content = response.choices[0]?.message?.content;
  if (!content) {
    throw new Error('Failed to find research gaps');
  }

  const result = JSON.parse(content);
  return result.gaps || [];
}

export async function answerResearchQuestion(
  question: string,
  context: {
    papers?: Array<{ title: string; abstract: string | null }>;
    chatHistory?: Array<{ role: string; content: string }>;
  }
): Promise<string> {
  checkApiKey();
  
  const messages: any[] = [
    {
      role: 'system',
      content: 'You are an expert research mentor helping students and researchers understand academic papers. Provide clear, accurate, and helpful responses.',
    },
  ];

  if (context.chatHistory) {
    messages.push(...context.chatHistory);
  }

  let userMessage = question;
  
  if (context.papers && context.papers.length > 0) {
    const papersContext = context.papers.map(p => 
      `Title: ${p.title}\nAbstract: ${p.abstract || 'N/A'}`
    ).join('\n\n');
    userMessage = `Context papers:\n${papersContext}\n\nQuestion: ${question}`;
  }

  messages.push({
    role: 'user',
    content: userMessage,
  });

  const response = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages,
    temperature: 0.7,
    max_tokens: 1000,
  });

  return response.choices[0]?.message?.content || 'Unable to generate a response.';
}

export async function generateCitation(
  paper: {
    title: string;
    authors?: any;
    year?: number | null;
    venue?: string | null;
    doi?: string | null;
    url?: string | null;
  },
  style: 'apa' | 'mla' | 'ieee' | 'chicago' | 'bibtex'
): Promise<string> {
  checkApiKey();
  
  const authorsText = Array.isArray(paper.authors) 
    ? paper.authors.map((a: any) => a.name || a).join(', ')
    : 'Unknown Author';

  const prompt = `Generate a ${style.toUpperCase()} citation for the following paper:

Title: ${paper.title}
Authors: ${authorsText}
Year: ${paper.year || 'n.d.'}
Venue: ${paper.venue || 'Unpublished'}
DOI: ${paper.doi || 'N/A'}
URL: ${paper.url || 'N/A'}

Provide only the citation text, properly formatted according to ${style.toUpperCase()} style.`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [
      {
        role: 'system',
        content: 'You are an expert in academic citation styles. Provide accurate, properly formatted citations.',
      },
      {
        role: 'user',
        content: prompt,
      },
    ],
    temperature: 0.3,
    max_tokens: 300,
  });

  return response.choices[0]?.message?.content || 'Unable to generate citation.';
}

export async function generateFlashcards(
  paper: {
    title: string;
    abstract: string | null;
  },
  count: number = 5
): Promise<Array<{ question: string; answer: string; difficulty: string }>> {
  checkApiKey();
  
  const prompt = `Generate ${count} flashcards to help students learn and remember the key concepts from this paper:

Title: ${paper.title}
Abstract: ${paper.abstract || 'No abstract available'}

Create flashcards covering:
- Key concepts and definitions
- Main findings
- Methodology
- Important technical terms

Provide a JSON array with: question, answer, difficulty (easy/medium/hard)`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [
      {
        role: 'system',
        content: 'You are an expert educator. Always respond with valid JSON.',
      },
      {
        role: 'user',
        content: prompt,
      },
    ],
    temperature: 0.8,
    max_tokens: 1500,
    response_format: { type: 'json_object' },
  });

  const content = response.choices[0]?.message?.content;
  if (!content) {
    throw new Error('Failed to generate flashcards');
  }

  const result = JSON.parse(content);
  return result.flashcards || [];
}

export { openai };
