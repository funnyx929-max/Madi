// Integration with various academic search APIs

export interface SearchFilters {
  year?: { min?: number; max?: number };
  citationCount?: { min?: number };
  fields?: string[];
  isOpenAccess?: boolean;
  author?: string;
  venue?: string;
}

export interface SearchResult {
  id: string;
  source: string;
  title: string;
  abstract?: string;
  authors: Array<{ name: string; affiliation?: string }>;
  year?: number;
  venue?: string;
  citationCount?: number;
  url?: string;
  pdfUrl?: string;
  doi?: string;
  isOpenAccess?: boolean;
  fields?: string[];
  tldr?: string;
}

export async function searchSemanticScholar(
  query: string,
  filters?: SearchFilters,
  limit: number = 10
): Promise<SearchResult[]> {
  const params = new URLSearchParams({
    query,
    limit: limit.toString(),
    fields: 'paperId,title,abstract,authors,year,venue,citationCount,openAccessPdf,externalIds,fieldsOfStudy,tldr',
  });

  if (filters?.year?.min) {
    params.append('year', `${filters.year.min}-${filters.year.max || new Date().getFullYear()}`);
  }

  if (filters?.fields && filters.fields.length > 0) {
    params.append('fieldsOfStudy', filters.fields.join(','));
  }

  if (filters?.isOpenAccess) {
    params.append('openAccessPdf', '');
  }

  const response = await fetch(
    `https://api.semanticscholar.org/graph/v1/paper/search?${params}`,
    {
      headers: {
        'x-api-key': process.env.SEMANTIC_SCHOLAR_API_KEY || '',
      },
    }
  );

  if (!response.ok) {
    throw new Error(`Semantic Scholar API error: ${response.statusText}`);
  }

  const data = await response.json();
  
  return (data.data || []).map((paper: any) => ({
    id: paper.paperId,
    source: 'semanticscholar',
    title: paper.title,
    abstract: paper.abstract,
    authors: (paper.authors || []).map((a: any) => ({
      name: a.name,
      affiliation: a.affiliations?.[0],
    })),
    year: paper.year,
    venue: paper.venue,
    citationCount: paper.citationCount,
    url: `https://www.semanticscholar.org/paper/${paper.paperId}`,
    pdfUrl: paper.openAccessPdf?.url,
    doi: paper.externalIds?.DOI,
    isOpenAccess: !!paper.openAccessPdf,
    fields: paper.fieldsOfStudy || [],
    tldr: paper.tldr?.text,
  }));
}

export async function searchOpenAlex(
  query: string,
  filters?: SearchFilters,
  limit: number = 10
): Promise<SearchResult[]> {
  const params = new URLSearchParams({
    search: query,
    per_page: limit.toString(),
  });

  if (filters?.year?.min) {
    params.append('filter', `publication_year:${filters.year.min}-${filters.year.max || new Date().getFullYear()}`);
  }

  if (filters?.isOpenAccess) {
    params.append('filter', 'is_oa:true');
  }

  const response = await fetch(
    `https://api.openalex.org/works?${params}`,
    {
      headers: {
        'User-Agent': 'ResearchMind (mailto:contact@example.com)',
      },
    }
  );

  if (!response.ok) {
    throw new Error(`OpenAlex API error: ${response.statusText}`);
  }

  const data = await response.json();
  
  return (data.results || []).map((work: any) => ({
    id: work.id,
    source: 'openalex',
    title: work.title,
    abstract: work.abstract,
    authors: (work.authorships || []).map((a: any) => ({
      name: a.author?.display_name,
      affiliation: a.institutions?.[0]?.display_name,
    })),
    year: work.publication_year,
    venue: work.primary_location?.source?.display_name,
    citationCount: work.cited_by_count,
    url: work.id,
    pdfUrl: work.open_access?.oa_url,
    doi: work.doi?.replace('https://doi.org/', ''),
    isOpenAccess: work.open_access?.is_oa,
    fields: (work.concepts || []).slice(0, 5).map((c: any) => c.display_name),
  }));
}

export async function searchArxiv(
  query: string,
  filters?: SearchFilters,
  limit: number = 10
): Promise<SearchResult[]> {
  const searchQuery = filters?.fields && filters.fields.length > 0
    ? `${filters.fields[0]}:${query}`
    : `all:${query}`;

  const params = new URLSearchParams({
    search_query: searchQuery,
    max_results: limit.toString(),
    sortBy: 'relevance',
  });

  const response = await fetch(`http://export.arxiv.org/api/query?${params}`);
  
  if (!response.ok) {
    throw new Error(`arXiv API error: ${response.statusText}`);
  }

  const xmlText = await response.text();
  
  // Simple XML parsing (in production, use a proper XML parser)
  const entries = xmlText.match(/<entry>[\s\S]*?<\/entry>/g) || [];
  
  return entries.slice(0, limit).map((entry) => {
    const getTag = (tag: string) => {
      const match = entry.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`));
      return match ? match[1].trim() : '';
    };

    const getAllTags = (tag: string) => {
      const matches = entry.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`, 'g')) || [];
      return matches.map(m => {
        const content = m.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`))?.[1];
        return content?.trim() || '';
      });
    };

    const id = getTag('id').split('/').pop() || '';
    const authors = getAllTags('name');
    const year = new Date(getTag('published')).getFullYear();

    return {
      id,
      source: 'arxiv',
      title: getTag('title').replace(/\s+/g, ' '),
      abstract: getTag('summary').replace(/\s+/g, ' '),
      authors: authors.map(name => ({ name })),
      year,
      venue: 'arXiv',
      url: getTag('id'),
      pdfUrl: getTag('id').replace('/abs/', '/pdf/') + '.pdf',
      isOpenAccess: true,
      fields: getAllTags('category').map(cat => cat),
    };
  });
}

export async function searchPapers(
  query: string,
  sources: Array<'semanticscholar' | 'openalex' | 'arxiv'> = ['semanticscholar', 'openalex'],
  filters?: SearchFilters,
  limit: number = 10
): Promise<SearchResult[]> {
  const searchPromises = sources.map(async (source) => {
    try {
      switch (source) {
        case 'semanticscholar':
          return await searchSemanticScholar(query, filters, limit);
        case 'openalex':
          return await searchOpenAlex(query, filters, limit);
        case 'arxiv':
          return await searchArxiv(query, filters, limit);
        default:
          return [];
      }
    } catch (error) {
      console.error(`Error searching ${source}:`, error);
      return [];
    }
  });

  const results = await Promise.all(searchPromises);
  const combined = results.flat();

  // Remove duplicates based on title similarity
  const unique = combined.filter((paper, index, self) => 
    index === self.findIndex(p => 
      p.title.toLowerCase().trim() === paper.title.toLowerCase().trim()
    )
  );

  // Sort by citation count (if available)
  unique.sort((a, b) => (b.citationCount || 0) - (a.citationCount || 0));

  return unique.slice(0, limit);
}

export async function getRecommendedPapers(
  paperId: string,
  source: string,
  limit: number = 5
): Promise<SearchResult[]> {
  if (source === 'semanticscholar') {
    const response = await fetch(
      `https://api.semanticscholar.org/graph/v1/paper/${paperId}/recommendations?limit=${limit}&fields=paperId,title,abstract,authors,year,venue,citationCount`,
      {
        headers: {
          'x-api-key': process.env.SEMANTIC_SCHOLAR_API_KEY || '',
        },
      }
    );

    if (!response.ok) {
      return [];
    }

    const data = await response.json();
    
    return (data.recommendedPapers || []).map((paper: any) => ({
      id: paper.paperId,
      source: 'semanticscholar',
      title: paper.title,
      abstract: paper.abstract,
      authors: (paper.authors || []).map((a: any) => ({ name: a.name })),
      year: paper.year,
      venue: paper.venue,
      citationCount: paper.citationCount,
      url: `https://www.semanticscholar.org/paper/${paper.paperId}`,
    }));
  }

  return [];
}
