// Demo data for showcasing ResearchMind features

export const demoQuestions = [
  "Explain this paper in simple terms",
  "What are the key contributions of this work?",
  "How does this compare to previous approaches?",
  "What mathematical background do I need to understand this?",
  "What are the main limitations?",
  "What datasets were used in the experiments?",
  "How can I implement this in my own project?",
  "What are the ethical implications of this research?",
  "Which paper should I read next?",
  "What open problems remain in this area?",
];

export const demoTopics = [
  'Machine Learning',
  'Natural Language Processing',
  'Computer Vision',
  'Reinforcement Learning',
  'Deep Learning',
  'Transfer Learning',
  'Neural Networks',
  'Transformers',
  'Graph Neural Networks',
  'Federated Learning',
];

export const demoPapers = [
  {
    id: 'demo-1',
    source: 'semanticscholar',
    title: 'Attention Is All You Need',
    abstract: 'The dominant sequence transduction models are based on complex recurrent or convolutional neural networks that include an encoder and a decoder. The best performing models also connect the encoder and decoder through an attention mechanism. We propose a new simple network architecture, the Transformer, based solely on attention mechanisms, dispensing with recurrence and convolutions entirely.',
    authors: [
      { name: 'Ashish Vaswani' },
      { name: 'Noam Shazeer' },
      { name: 'Niki Parmar' },
      { name: 'Jakob Uszkoreit' },
    ],
    year: 2017,
    venue: 'NeurIPS',
    citationCount: 85000,
    isOpenAccess: true,
    fields: ['Machine Learning', 'Natural Language Processing', 'Deep Learning'],
    tldr: 'Introduces the Transformer architecture, which relies entirely on self-attention mechanisms and eliminates recurrence, achieving state-of-the-art results in machine translation.',
  },
  {
    id: 'demo-2',
    source: 'semanticscholar',
    title: 'BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding',
    abstract: 'We introduce a new language representation model called BERT, which stands for Bidirectional Encoder Representations from Transformers. Unlike recent language representation models, BERT is designed to pre-train deep bidirectional representations from unlabeled text by jointly conditioning on both left and right context in all layers.',
    authors: [
      { name: 'Jacob Devlin' },
      { name: 'Ming-Wei Chang' },
      { name: 'Kenton Lee' },
      { name: 'Kristina Toutanova' },
    ],
    year: 2018,
    venue: 'NAACL',
    citationCount: 65000,
    isOpenAccess: true,
    fields: ['Natural Language Processing', 'Transfer Learning', 'Deep Learning'],
    tldr: 'BERT pre-trains deep bidirectional transformers using masked language modeling and next sentence prediction, achieving state-of-the-art results on eleven NLP tasks.',
  },
  {
    id: 'demo-3',
    source: 'arxiv',
    title: 'Language Models are Few-Shot Learners',
    abstract: 'Recent work has demonstrated substantial gains on many NLP tasks and benchmarks by pre-training on a large corpus of text followed by fine-tuning on a specific task. While typically task-agnostic in architecture, this method still requires task-specific fine-tuning datasets of thousands or tens of thousands of examples. We show that scaling up language models greatly improves task-agnostic, few-shot performance.',
    authors: [
      { name: 'Tom B. Brown' },
      { name: 'Benjamin Mann' },
      { name: 'Nick Ryder' },
      { name: 'OpenAI' },
    ],
    year: 2020,
    venue: 'NeurIPS',
    citationCount: 45000,
    isOpenAccess: true,
    fields: ['Natural Language Processing', 'Few-Shot Learning', 'Large Language Models'],
    tldr: 'GPT-3 demonstrates that scaling language models to 175 billion parameters enables strong few-shot learning across diverse NLP tasks without fine-tuning.',
  },
];

export const demoProjects = [
  {
    id: 'proj-1',
    name: 'Transformer Architectures',
    description: 'Collection of papers on transformer models and their applications',
    color: 'bg-blue-500',
    icon: '🤖',
    paperCount: 15,
  },
  {
    id: 'proj-2',
    name: 'NLP Survey',
    description: 'Papers for literature review on modern NLP techniques',
    color: 'bg-purple-500',
    icon: '📚',
    paperCount: 23,
  },
  {
    id: 'proj-3',
    name: 'PhD Research',
    description: 'Papers related to my doctoral research on transfer learning',
    color: 'bg-green-500',
    icon: '🎓',
    paperCount: 47,
  },
];

export const demoStats = {
  papersRead: 127,
  readingStreak: 23,
  totalReadingTime: 8450, // minutes
  favoriteTopics: [
    { topic: 'Natural Language Processing', count: 45, percentage: 35.4 },
    { topic: 'Machine Learning', count: 38, percentage: 29.9 },
    { topic: 'Computer Vision', count: 24, percentage: 18.9 },
    { topic: 'Reinforcement Learning', count: 20, percentage: 15.7 },
  ],
  monthlyStats: {
    '2024-01': { papersRead: 12, readingTime: 780 },
    '2024-02': { papersRead: 15, readingTime: 920 },
    '2024-03': { papersRead: 18, readingTime: 1050 },
    '2024-04': { papersRead: 20, readingTime: 1200 },
  },
};

export const demoFlashcards = [
  {
    question: 'What is the main innovation of the Transformer architecture?',
    answer: 'The Transformer replaces recurrence with self-attention mechanisms, allowing for better parallelization and capturing long-range dependencies more effectively.',
    difficulty: 'medium',
  },
  {
    question: 'What are the two pre-training objectives used in BERT?',
    answer: 'Masked Language Modeling (MLM) and Next Sentence Prediction (NSP).',
    difficulty: 'easy',
  },
  {
    question: 'Why is GPT-3 considered a few-shot learner?',
    answer: 'GPT-3 can perform new tasks with only a few examples provided in the prompt, without requiring fine-tuning on task-specific datasets.',
    difficulty: 'medium',
  },
];

export const demoResearchGaps = [
  {
    title: 'Computational Efficiency of Large Models',
    description: 'Most papers focus on model performance but overlook the computational cost and environmental impact of training large-scale models. There is a gap in research on efficient training methods and model compression techniques.',
    category: 'underexplored',
    severity: 'high',
    relatedPapers: ['demo-2', 'demo-3'],
  },
  {
    title: 'Multilingual Transfer Learning',
    description: 'While transformer models excel in English, their performance on low-resource languages remains limited. Research on effective cross-lingual transfer is still developing.',
    category: 'limitation',
    severity: 'medium',
    relatedPapers: ['demo-1', 'demo-2'],
  },
  {
    title: 'Interpretability and Explainability',
    description: 'Contradictory findings exist regarding what information transformers encode in different layers and attention heads. A unified theory of transformer interpretability is needed.',
    category: 'contradictory',
    severity: 'high',
    relatedPapers: ['demo-1', 'demo-2', 'demo-3'],
  },
];

export const demoLiteratureReview = {
  introduction: 'The field of Natural Language Processing has undergone a paradigm shift with the introduction of transformer-based architectures. This literature review examines the evolution from the original Transformer (Vaswani et al., 2017) through BERT (Devlin et al., 2018) to GPT-3 (Brown et al., 2020), highlighting key innovations, methodological approaches, and their impact on the field.',
  sections: [
    {
      title: 'Architectural Innovations',
      content: 'The Transformer architecture introduced by Vaswani et al. (2017) marked a departure from recurrent neural networks by relying entirely on attention mechanisms. This design choice enabled better parallelization and improved handling of long-range dependencies. BERT built upon this foundation by introducing bidirectional pre-training through masked language modeling, while GPT-3 demonstrated that scaling model size could unlock few-shot learning capabilities.',
    },
    {
      title: 'Pre-training Methodologies',
      content: 'A key theme across these works is the importance of pre-training on large text corpora. BERT\'s masked language modeling and next sentence prediction objectives differ from GPT-3\'s autoregressive approach, yet both achieve strong transfer learning performance. This suggests that the choice of pre-training objective may be less critical than model scale and training data quality.',
    },
    {
      title: 'Performance and Applications',
      content: 'All three models achieved state-of-the-art results on standard NLP benchmarks, with each successive model expanding the range of tasks and improving performance. The progression from task-specific fine-tuning (BERT) to few-shot learning (GPT-3) represents a significant shift toward more general-purpose language understanding.',
    },
  ],
  conclusion: 'The evolution from Transformer to GPT-3 demonstrates a clear trend toward larger, more general-purpose models. However, this progression raises important questions about computational efficiency, environmental impact, and accessibility. Future research should balance performance improvements with practical considerations and explore methods to democratize access to powerful language models.',
};

export const keyboardShortcuts = [
  { keys: ['Cmd', 'K'], description: 'Quick search' },
  { keys: ['Cmd', 'N'], description: 'New project' },
  { keys: ['Cmd', 'E'], description: 'Explain paper' },
  { keys: ['Cmd', 'C'], description: 'Copy citation' },
  { keys: ['Cmd', 'S'], description: 'Save note' },
  { keys: ['Esc'], description: 'Close modal' },
];
