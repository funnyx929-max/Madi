import { pgTable, text, timestamp, integer, boolean, jsonb, serial, varchar, uuid } from 'drizzle-orm/pg-core';

// Users table
export const users = pgTable('users', {
  id: uuid('id').defaultRandom().primaryKey(),
  email: varchar('email', { length: 255 }).notNull().unique(),
  name: varchar('name', { length: 255 }).notNull(),
  password: varchar('password', { length: 255 }).notNull(),
  avatar: text('avatar'),
  preferences: jsonb('preferences').$type<{
    theme?: 'light' | 'dark';
    defaultExplanationLevel?: 'beginner' | 'undergraduate' | 'graduate' | 'expert';
    favoriteTopics?: string[];
  }>().default({}),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Papers table
export const papers = pgTable('papers', {
  id: uuid('id').defaultRandom().primaryKey(),
  externalId: varchar('external_id', { length: 255 }), // ID from external source (arXiv, Semantic Scholar, etc.)
  source: varchar('source', { length: 50 }), // 'arxiv', 'semanticscholar', 'openalex', etc.
  title: text('title').notNull(),
  abstract: text('abstract'),
  authors: jsonb('authors').$type<Array<{
    name: string;
    affiliation?: string;
    id?: string;
  }>>(),
  venue: varchar('venue', { length: 255 }),
  year: integer('year'),
  citationCount: integer('citation_count').default(0),
  publicationDate: timestamp('publication_date'),
  doi: varchar('doi', { length: 255 }),
  url: text('url'),
  pdfUrl: text('pdf_url'),
  isOpenAccess: boolean('is_open_access').default(false),
  fields: jsonb('fields').$type<string[]>(),
  keywords: jsonb('keywords').$type<string[]>(),
  references: jsonb('references').$type<string[]>(),
  tldr: text('tldr'),
  metadata: jsonb('metadata'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Projects/Collections
export const projects = pgTable('projects', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  name: varchar('name', { length: 255 }).notNull(),
  description: text('description'),
  color: varchar('color', { length: 50 }),
  icon: varchar('icon', { length: 50 }),
  isShared: boolean('is_shared').default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Project Papers (many-to-many relationship)
export const projectPapers = pgTable('project_papers', {
  id: uuid('id').defaultRandom().primaryKey(),
  projectId: uuid('project_id').references(() => projects.id, { onDelete: 'cascade' }).notNull(),
  paperId: uuid('paper_id').references(() => papers.id, { onDelete: 'cascade' }).notNull(),
  addedAt: timestamp('added_at').defaultNow().notNull(),
  position: integer('position').default(0),
});

// User paper interactions
export const userPapers = pgTable('user_papers', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  paperId: uuid('paper_id').references(() => papers.id, { onDelete: 'cascade' }).notNull(),
  status: varchar('status', { length: 50 }).default('to-read'), // 'to-read', 'reading', 'completed'
  rating: integer('rating'),
  progress: integer('progress').default(0), // 0-100
  readingTime: integer('reading_time').default(0), // in minutes
  isFavorite: boolean('is_favorite').default(false),
  lastReadAt: timestamp('last_read_at'),
  completedAt: timestamp('completed_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Notes
export const notes = pgTable('notes', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  paperId: uuid('paper_id').references(() => papers.id, { onDelete: 'cascade' }),
  projectId: uuid('project_id').references(() => projects.id, { onDelete: 'cascade' }),
  content: text('content').notNull(),
  pageNumber: integer('page_number'),
  position: jsonb('position').$type<{ x: number; y: number }>(),
  color: varchar('color', { length: 50 }),
  isShared: boolean('is_shared').default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Highlights
export const highlights = pgTable('highlights', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  paperId: uuid('paper_id').references(() => papers.id, { onDelete: 'cascade' }).notNull(),
  text: text('text').notNull(),
  pageNumber: integer('page_number'),
  position: jsonb('position').$type<{ start: number; end: number }>(),
  color: varchar('color', { length: 50 }).default('yellow'),
  noteId: uuid('note_id').references(() => notes.id, { onDelete: 'set null' }),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// AI Interactions/Chats
export const aiChats = pgTable('ai_chats', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  paperId: uuid('paper_id').references(() => papers.id, { onDelete: 'cascade' }),
  projectId: uuid('project_id').references(() => projects.id, { onDelete: 'cascade' }),
  title: varchar('title', { length: 255 }),
  messages: jsonb('messages').$type<Array<{
    role: 'user' | 'assistant' | 'system';
    content: string;
    timestamp: string;
  }>>().default([]),
  type: varchar('type', { length: 50 }), // 'paper-explanation', 'literature-review', 'research-gaps', etc.
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Literature Reviews
export const literatureReviews = pgTable('literature_reviews', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid('project_id').references(() => projects.id, { onDelete: 'cascade' }),
  title: varchar('title', { length: 255 }).notNull(),
  content: text('content'),
  paperIds: jsonb('paper_ids').$type<string[]>().default([]),
  structure: jsonb('structure').$type<{
    sections: Array<{
      title: string;
      content: string;
      papers: string[];
    }>;
  }>(),
  citationStyle: varchar('citation_style', { length: 50 }).default('apa'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Research Gaps
export const researchGaps = pgTable('research_gaps', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  projectId: uuid('project_id').references(() => projects.id, { onDelete: 'cascade' }),
  title: varchar('title', { length: 255 }).notNull(),
  description: text('description'),
  category: varchar('category', { length: 50 }), // 'underexplored', 'contradictory', 'limitation', 'future-work'
  relatedPapers: jsonb('related_papers').$type<string[]>().default([]),
  severity: varchar('severity', { length: 50 }), // 'low', 'medium', 'high'
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Study Sessions (for tracking reading progress)
export const studySessions = pgTable('study_sessions', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  paperId: uuid('paper_id').references(() => papers.id, { onDelete: 'cascade' }),
  duration: integer('duration').notNull(), // in seconds
  startedAt: timestamp('started_at').notNull(),
  endedAt: timestamp('ended_at').notNull(),
});

// Flashcards
export const flashcards = pgTable('flashcards', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  paperId: uuid('paper_id').references(() => papers.id, { onDelete: 'cascade' }),
  projectId: uuid('project_id').references(() => projects.id, { onDelete: 'cascade' }),
  question: text('question').notNull(),
  answer: text('answer').notNull(),
  difficulty: varchar('difficulty', { length: 50 }),
  nextReview: timestamp('next_review'),
  timesReviewed: integer('times_reviewed').default(0),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Citations
export const citations = pgTable('citations', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  paperId: uuid('paper_id').references(() => papers.id, { onDelete: 'cascade' }).notNull(),
  style: varchar('style', { length: 50 }).notNull(), // 'apa', 'mla', 'ieee', 'chicago', 'bibtex'
  citation: text('citation').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// User Statistics (denormalized for performance)
export const userStats = pgTable('user_stats', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull().unique(),
  papersRead: integer('papers_read').default(0),
  readingStreak: integer('reading_streak').default(0),
  totalReadingTime: integer('total_reading_time').default(0), // in minutes
  lastReadDate: timestamp('last_read_date'),
  topTopics: jsonb('top_topics').$type<Array<{ topic: string; count: number }>>().default([]),
  monthlyStats: jsonb('monthly_stats').$type<Record<string, {
    papersRead: number;
    readingTime: number;
  }>>().default({}),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Paper = typeof papers.$inferSelect;
export type InsertPaper = typeof papers.$inferInsert;
export type Project = typeof projects.$inferSelect;
export type InsertProject = typeof projects.$inferInsert;
export type Note = typeof notes.$inferSelect;
export type InsertNote = typeof notes.$inferInsert;
export type AiChat = typeof aiChats.$inferSelect;
export type InsertAiChat = typeof aiChats.$inferInsert;
