'use client';

import { useRouter } from 'next/navigation';
import toast from 'react-hot-toast';
import { FileText, ExternalLink, Download, BookOpen, Quote, Star, Plus, Brain } from 'lucide-react';
import { Badge } from './ui/Badge';
import { formatDate, truncateText } from '@/lib/utils';

interface PaperCardProps {
  paper: {
    id: string;
    title: string;
    abstract?: string;
    authors: Array<{ name: string; affiliation?: string }>;
    year?: number;
    venue?: string;
    citationCount?: number;
    url?: string;
    pdfUrl?: string;
    isOpenAccess?: boolean;
    fields?: string[];
    tldr?: string;
  };
  onSelect?: (paper: any) => void;
  onExplain?: (paper: any) => void;
  onCite?: (paper: any) => void;
}

export function PaperCard({ paper, onSelect, onExplain, onCite }: PaperCardProps) {
  const router = useRouter();

  const handleStudy = () => {
    const paperData = encodeURIComponent(JSON.stringify({
      id: paper.id,
      title: paper.title,
      abstract: paper.abstract,
    }));
    router.push(`/study?paper=${paperData}`);
  };
  const authorNames = paper.authors.slice(0, 3).map(a => a.name).join(', ');
  const moreAuthors = paper.authors.length > 3 ? ` +${paper.authors.length - 3} more` : '';

  return (
    <div
      className="paper-card bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-6 cursor-pointer"
      onClick={() => onSelect?.(paper)}
    >
      <div className="flex justify-between items-start gap-4 mb-3">
        <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100 leading-tight flex-1">
          {paper.title}
        </h3>
        {paper.isOpenAccess && (
          <Badge variant="success" className="flex-shrink-0">
            Open Access
          </Badge>
        )}
      </div>

      <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400 mb-3">
        <span className="font-medium">{authorNames}{moreAuthors}</span>
        {paper.year && (
          <>
            <span>•</span>
            <span>{paper.year}</span>
          </>
        )}
        {paper.venue && (
          <>
            <span>•</span>
            <span className="truncate">{truncateText(paper.venue, 50)}</span>
          </>
        )}
      </div>

      {paper.tldr && (
        <div className="mb-3 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
          <p className="text-sm text-blue-900 dark:text-blue-100">
            <strong>TL;DR:</strong> {paper.tldr}
          </p>
        </div>
      )}

      {paper.abstract && (
        <p className="text-sm text-slate-700 dark:text-slate-300 mb-4 line-clamp-3">
          {truncateText(paper.abstract, 250)}
        </p>
      )}

      <div className="flex flex-wrap gap-2 mb-4">
        {paper.fields?.slice(0, 3).map((field, idx) => (
          <Badge key={idx} variant="outline">
            {field}
          </Badge>
        ))}
      </div>

      <div className="flex items-center justify-between pt-4 border-t border-slate-200 dark:border-slate-700">
        <div className="flex items-center gap-4 text-sm text-slate-600 dark:text-slate-400">
          {paper.citationCount !== undefined && (
            <div className="flex items-center gap-1">
              <Quote className="w-4 h-4" />
              <span>{paper.citationCount.toLocaleString()} citations</span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={(e) => {
              e.stopPropagation();
              toast.success('Added to reading list!');
            }}
            className="p-2 text-slate-600 dark:text-slate-400 hover:text-yellow-600 dark:hover:text-yellow-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
            title="Add to project"
          >
            <Plus className="w-5 h-5" />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleStudy();
            }}
            className="p-2 text-slate-600 dark:text-slate-400 hover:text-purple-600 dark:hover:text-purple-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
            title="Study this paper"
          >
            <Brain className="w-5 h-5" />
          </button>
          {onExplain && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onExplain(paper);
              }}
              className="p-2 text-slate-600 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
              title="Explain this paper"
            >
              <BookOpen className="w-5 h-5" />
            </button>
          )}
          {onCite && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onCite(paper);
              }}
              className="p-2 text-slate-600 dark:text-slate-400 hover:text-purple-600 dark:hover:text-purple-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
              title="Generate citation"
            >
              <Quote className="w-5 h-5" />
            </button>
          )}
          {paper.pdfUrl && (
            <a
              href={paper.pdfUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => e.stopPropagation()}
              className="p-2 text-slate-600 dark:text-slate-400 hover:text-green-600 dark:hover:text-green-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
              title="Download PDF"
            >
              <Download className="w-5 h-5" />
            </a>
          )}
          {paper.url && (
            <a
              href={paper.url}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => e.stopPropagation()}
              className="p-2 text-slate-600 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
              title="View on source"
            >
              <ExternalLink className="w-5 h-5" />
            </a>
          )}
        </div>
      </div>
    </div>
  );
}
