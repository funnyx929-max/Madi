'use client';

import { useState } from 'react';
import toast from 'react-hot-toast';
import { X, BookOpen, Quote, Sparkles, Download, ExternalLink } from 'lucide-react';
import { Button } from './ui/Button';
import { Badge } from './ui/Badge';
import { formatDate } from '@/lib/utils';

interface PaperModalProps {
  paper: any;
  onClose: () => void;
}

export function PaperModal({ paper, onClose }: PaperModalProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'explain' | 'cite'>('overview');
  const [explanationLevel, setExplanationLevel] = useState<'beginner' | 'undergraduate' | 'graduate' | 'expert'>('undergraduate');
  const [explanation, setExplanation] = useState<string>('');
  const [citation, setCitation] = useState<string>('');
  const [citationStyle, setCitationStyle] = useState<'apa' | 'mla' | 'ieee' | 'chicago' | 'bibtex'>('apa');
  const [isLoading, setIsLoading] = useState(false);

  const handleExplain = async () => {
    setIsLoading(true);
    toast.loading('Generating explanation...', { id: 'explain' });
    try {
      const response = await fetch('/api/ai/explain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ paper, level: explanationLevel }),
      });
      const data = await response.json();
      setExplanation(data.explanation);
      toast.success('Explanation generated!', { id: 'explain' });
    } catch (error) {
      console.error('Failed to generate explanation:', error);
      setExplanation('Failed to generate explanation. Please try again.');
      toast.error('Failed to generate explanation', { id: 'explain' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCitation = async () => {
    setIsLoading(true);
    toast.loading('Generating citation...', { id: 'citation' });
    try {
      const response = await fetch('/api/ai/citation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ paper, style: citationStyle }),
      });
      const data = await response.json();
      setCitation(data.citation);
      toast.success('Citation generated!', { id: 'citation' });
    } catch (error) {
      console.error('Failed to generate citation:', error);
      setCitation('Failed to generate citation. Please try again.');
      toast.error('Failed to generate citation', { id: 'citation' });
    } finally {
      setIsLoading(false);
    }
  };

  const authorNames = paper.authors?.map((a: any) => a.name).join(', ') || 'Unknown Authors';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-slate-200 dark:border-slate-700 flex justify-between items-start">
          <div className="flex-1 pr-4">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100 mb-2">
              {paper.title}
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              {authorNames}
            </p>
            {paper.year && (
              <p className="text-sm text-slate-600 dark:text-slate-400">
                {paper.venue ? `${paper.venue} • ` : ''}{paper.year}
              </p>
            )}
            <div className="flex flex-wrap gap-2 mt-3">
              {paper.isOpenAccess && (
                <Badge variant="success">Open Access</Badge>
              )}
              {paper.citationCount !== undefined && (
                <Badge variant="outline">{paper.citationCount} citations</Badge>
              )}
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Tabs */}
        <div className="border-b border-slate-200 dark:border-slate-700 px-6">
          <div className="flex gap-4">
            <button
              onClick={() => setActiveTab('overview')}
              className={`py-3 px-1 font-medium text-sm border-b-2 transition-colors ${
                activeTab === 'overview'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => {
                setActiveTab('explain');
                if (!explanation) handleExplain();
              }}
              className={`py-3 px-1 font-medium text-sm border-b-2 transition-colors flex items-center gap-2 ${
                activeTab === 'explain'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              AI Explanation
            </button>
            <button
              onClick={() => {
                setActiveTab('cite');
                if (!citation) handleCitation();
              }}
              className={`py-3 px-1 font-medium text-sm border-b-2 transition-colors flex items-center gap-2 ${
                activeTab === 'cite'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <Quote className="w-4 h-4" />
              Citations
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {paper.tldr && (
                <div className="p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                  <h3 className="text-sm font-semibold text-blue-900 dark:text-blue-100 mb-2">
                    TL;DR
                  </h3>
                  <p className="text-sm text-blue-900 dark:text-blue-100">
                    {paper.tldr}
                  </p>
                </div>
              )}

              {paper.abstract && (
                <div>
                  <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-2">
                    Abstract
                  </h3>
                  <p className="text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
                    {paper.abstract}
                  </p>
                </div>
              )}

              {paper.fields && paper.fields.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-2">
                    Fields of Study
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {paper.fields.map((field: string, idx: number) => (
                      <Badge key={idx} variant="outline">
                        {field}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex gap-3">
                {paper.pdfUrl && (
                  <a
                    href={paper.pdfUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                  >
                    <Download className="w-4 h-4" />
                    Download PDF
                  </a>
                )}
                {paper.url && (
                  <a
                    href={paper.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <ExternalLink className="w-4 h-4" />
                    View Source
                  </a>
                )}
              </div>
            </div>
          )}

          {activeTab === 'explain' && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  Explanation Level
                </label>
                <div className="flex flex-wrap gap-2">
                  {(['beginner', 'undergraduate', 'graduate', 'expert'] as const).map((level) => (
                    <button
                      key={level}
                      onClick={() => {
                        setExplanationLevel(level);
                        setExplanation('');
                      }}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                        explanationLevel === level
                          ? 'bg-blue-600 text-white'
                          : 'bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600'
                      }`}
                    >
                      {level.charAt(0).toUpperCase() + level.slice(1)}
                    </button>
                  ))}
                </div>
              </div>

              {!explanation && (
                <Button onClick={handleExplain} disabled={isLoading}>
                  {isLoading ? 'Generating...' : 'Generate Explanation'}
                </Button>
              )}

              {explanation && (
                <div className="prose dark:prose-invert max-w-none">
                  <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg whitespace-pre-wrap">
                    {explanation}
                  </div>
                  <Button onClick={handleExplain} variant="outline" className="mt-4" disabled={isLoading}>
                    Regenerate
                  </Button>
                </div>
              )}
            </div>
          )}

          {activeTab === 'cite' && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  Citation Style
                </label>
                <div className="flex flex-wrap gap-2">
                  {(['apa', 'mla', 'ieee', 'chicago', 'bibtex'] as const).map((style) => (
                    <button
                      key={style}
                      onClick={() => {
                        setCitationStyle(style);
                        setCitation('');
                      }}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                        citationStyle === style
                          ? 'bg-blue-600 text-white'
                          : 'bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600'
                      }`}
                    >
                      {style.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>

              {!citation && (
                <Button onClick={handleCitation} disabled={isLoading}>
                  {isLoading ? 'Generating...' : 'Generate Citation'}
                </Button>
              )}

              {citation && (
                <div>
                  <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg font-mono text-sm whitespace-pre-wrap">
                    {citation}
                  </div>
                  <div className="flex gap-2 mt-4">
                    <Button
                      onClick={() => {
                        navigator.clipboard.writeText(citation);
                        toast.success('Citation copied to clipboard!');
                      }}
                      variant="outline"
                    >
                      Copy to Clipboard
                    </Button>
                    <Button onClick={handleCitation} variant="outline" disabled={isLoading}>
                      Regenerate
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
