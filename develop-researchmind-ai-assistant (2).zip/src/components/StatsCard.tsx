import { LucideIcon } from 'lucide-react';
import { Card, CardContent } from './ui/Card';
import { Badge } from './ui/Badge';

interface StatsCardProps {
  icon: LucideIcon;
  iconColor?: string;
  title: string;
  value: string | number;
  badge?: {
    text: string;
    variant?: 'default' | 'primary' | 'success' | 'warning' | 'danger';
  };
  trend?: {
    value: number;
    label: string;
    isPositive?: boolean;
  };
}

export function StatsCard({ 
  icon: Icon, 
  iconColor = 'bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-400',
  title, 
  value, 
  badge,
  trend 
}: StatsCardProps) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-2">
          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${iconColor}`}>
            <Icon className="w-5 h-5" />
          </div>
          {badge && (
            <Badge variant={badge.variant}>
              {badge.text}
            </Badge>
          )}
        </div>
        <div className="text-3xl font-bold text-slate-900 dark:text-slate-100 mb-1">
          {value}
        </div>
        <div className="text-sm text-slate-600 dark:text-slate-400">
          {title}
        </div>
        {trend && (
          <div className="mt-2 flex items-center gap-1 text-xs">
            <span className={trend.isPositive !== false ? 'text-green-600' : 'text-red-600'}>
              {trend.isPositive !== false ? '↑' : '↓'} {trend.value}%
            </span>
            <span className="text-slate-500 dark:text-slate-400">
              {trend.label}
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
