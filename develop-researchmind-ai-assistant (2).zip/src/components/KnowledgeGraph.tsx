'use client';

import { useCallback, useEffect, useState } from 'react';
import ReactFlow, {
  Node,
  Edge,
  Background,
  Controls,
  MiniMap,
  useNodesState,
  useEdgesState,
  addEdge,
  Connection,
} from 'reactflow';
import 'reactflow/dist/style.css';
import { Card, CardContent, CardHeader } from './ui/Card';

interface KnowledgeGraphProps {
  papers?: any[];
}

const nodeTypes = {
  paper: ({ data }: any) => (
    <div className="px-4 py-2 shadow-lg rounded-lg bg-blue-100 dark:bg-blue-900 border-2 border-blue-500">
      <div className="font-bold text-xs text-blue-900 dark:text-blue-100">{data.label}</div>
    </div>
  ),
  author: ({ data }: any) => (
    <div className="px-4 py-2 shadow-lg rounded-full bg-green-100 dark:bg-green-900 border-2 border-green-500">
      <div className="font-medium text-xs text-green-900 dark:text-green-100">{data.label}</div>
    </div>
  ),
  concept: ({ data }: any) => (
    <div className="px-4 py-2 shadow-lg rounded-lg bg-purple-100 dark:bg-purple-900 border-2 border-purple-500">
      <div className="font-medium text-xs text-purple-900 dark:text-purple-100">{data.label}</div>
    </div>
  ),
};

export function KnowledgeGraph({ papers = [] }: KnowledgeGraphProps) {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);

  const onConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  useEffect(() => {
    // Generate sample graph data
    const sampleNodes: Node[] = [
      {
        id: 'p1',
        type: 'paper',
        position: { x: 250, y: 0 },
        data: { label: 'Attention Is All You Need' },
      },
      {
        id: 'p2',
        type: 'paper',
        position: { x: 100, y: 200 },
        data: { label: 'BERT' },
      },
      {
        id: 'p3',
        type: 'paper',
        position: { x: 400, y: 200 },
        data: { label: 'GPT-3' },
      },
      {
        id: 'a1',
        type: 'author',
        position: { x: 250, y: 100 },
        data: { label: 'Vaswani et al.' },
      },
      {
        id: 'c1',
        type: 'concept',
        position: { x: 0, y: 100 },
        data: { label: 'Transformers' },
      },
      {
        id: 'c2',
        type: 'concept',
        position: { x: 500, y: 100 },
        data: { label: 'Self-Attention' },
      },
    ];

    const sampleEdges: Edge[] = [
      { id: 'e1', source: 'p1', target: 'a1', type: 'smoothstep', label: 'authored by' },
      { id: 'e2', source: 'p1', target: 'c1', type: 'smoothstep', label: 'introduces' },
      { id: 'e3', source: 'p1', target: 'c2', type: 'smoothstep', label: 'uses' },
      { id: 'e4', source: 'p2', target: 'c1', type: 'smoothstep', label: 'based on' },
      { id: 'e5', source: 'p3', target: 'c1', type: 'smoothstep', label: 'based on' },
      { id: 'e6', source: 'p2', target: 'p1', type: 'smoothstep', label: 'cites', animated: true },
      { id: 'e7', source: 'p3', target: 'p1', type: 'smoothstep', label: 'cites', animated: true },
    ];

    setNodes(sampleNodes);
    setEdges(sampleEdges);
  }, [papers, setNodes, setEdges]);

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <h3 className="text-xl font-semibold text-slate-900 dark:text-slate-100">
            Knowledge Graph
          </h3>
          <div className="flex gap-2 text-xs">
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded bg-blue-500"></div>
              <span className="text-slate-600 dark:text-slate-400">Papers</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded-full bg-green-500"></div>
              <span className="text-slate-600 dark:text-slate-400">Authors</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded bg-purple-500"></div>
              <span className="text-slate-600 dark:text-slate-400">Concepts</span>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div style={{ height: '500px', width: '100%' }}>
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onConnect={onConnect}
            nodeTypes={nodeTypes}
            fitView
          >
            <Background />
            <Controls />
            <MiniMap
              nodeStrokeWidth={3}
              zoomable
              pannable
            />
          </ReactFlow>
        </div>
      </CardContent>
    </Card>
  );
}
