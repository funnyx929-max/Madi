# ResearchMind Architecture

## Overview

ResearchMind is a fullstack web application built with Next.js App Router, TypeScript, PostgreSQL, and OpenAI. The architecture follows modern best practices with clear separation of concerns.

## Technology Stack

### Frontend
- **Framework:** Next.js 16 (React 19)
- **Language:** TypeScript 5.9
- **Styling:** Tailwind CSS 4
- **UI Components:** Custom component library
- **Visualization:** ReactFlow, Recharts
- **State:** React hooks (Zustand planned)

### Backend
- **Runtime:** Node.js
- **Framework:** Next.js API Routes
- **Database:** PostgreSQL 14+
- **ORM:** Drizzle ORM
- **External APIs:** Semantic Scholar, OpenAlex, arXiv

### AI & ML
- **Provider:** OpenAI
- **Model:** GPT-4o-mini
- **Use Cases:**
  - Paper explanations
  - Literature reviews
  - Research gap analysis
  - Citation generation
  - Flashcard creation
  - Chat interactions

## Directory Structure

```
researchmind/
├── src/
│   ├── app/                    # Next.js App Router
│   │   ├── api/               # API routes
│   │   │   ├── ai/           # AI features
│   │   │   │   ├── chat/
│   │   │   │   ├── citation/
│   │   │   │   ├── explain/
│   │   │   │   ├── flashcards/
│   │   │   │   ├── literature-review/
│   │   │   │   └── research-gaps/
│   │   │   ├── search/       # Paper search
│   │   │   └── health/       # Health check
│   │   ├── dashboard/        # User dashboard
│   │   ├── features/         # Features page
│   │   ├── tools/            # Research tools
│   │   ├── page.tsx          # Home page
│   │   ├── layout.tsx        # Root layout
│   │   └── globals.css       # Global styles
│   ├── components/            # React components
│   │   ├── ui/               # Base UI components
│   │   │   ├── Button.tsx
│   │   │   ├── Card.tsx
│   │   │   ├── Input.tsx
│   │   │   ├── Badge.tsx
│   │   │   ├── Loading.tsx
│   │   │   └── EmptyState.tsx
│   │   ├── SearchBar.tsx     # Paper search
│   │   ├── PaperCard.tsx     # Paper display
│   │   ├── PaperModal.tsx    # Paper details
│   │   ├── ResearchChat.tsx  # AI chat
│   │   ├── KnowledgeGraph.tsx # Graph viz
│   │   ├── ComparisonTable.tsx # Comparison
│   │   └── StatsCard.tsx     # Statistics
│   ├── db/                    # Database
│   │   ├── index.ts          # DB client
│   │   └── schema.ts         # Drizzle schema
│   └── lib/                   # Utilities
│       ├── openai.ts         # OpenAI functions
│       ├── paper-search.ts   # Search integration
│       ├── utils.ts          # Helper functions
│       └── demo-data.ts      # Demo data
├── public/                    # Static assets
├── .env                       # Environment variables
├── drizzle.config.json       # Drizzle configuration
├── tsconfig.json             # TypeScript config
├── package.json              # Dependencies
├── README.md                 # Main documentation
├── SETUP.md                  # Setup guide
└── ARCHITECTURE.md           # This file
```

## Data Flow

### Paper Search Flow

```
User Input → SearchBar Component
    ↓
    Query + Filters
    ↓
    /api/search Endpoint
    ↓
    searchPapers() Function
    ↓
    Parallel API Calls:
    - Semantic Scholar
    - OpenAlex
    - arXiv
    ↓
    Aggregate & Deduplicate Results
    ↓
    Return to Client
    ↓
    Display in PaperCard Components
```

### AI Explanation Flow

```
User Selects Paper → PaperModal
    ↓
    Paper + Level Selection
    ↓
    /api/ai/explain Endpoint
    ↓
    explainPaper() Function
    ↓
    OpenAI API Call (GPT-4o-mini)
    ↓
    Return Explanation
    ↓
    Display in Modal
```

### Literature Review Flow

```
User Selects Papers → Tools Page
    ↓
    Papers Array + Focus Area
    ↓
    /api/ai/literature-review
    ↓
    generateLiteratureReview()
    ↓
    OpenAI API Call (Structured Output)
    ↓
    Return: { introduction, sections, conclusion }
    ↓
    Display Formatted Review
```

## Database Schema

### Core Tables

**users**
- id (UUID, PK)
- email (unique)
- name
- password (hashed)
- preferences (JSONB)
- createdAt, updatedAt

**papers**
- id (UUID, PK)
- externalId (from API)
- source (semanticscholar, openalex, arxiv)
- title, abstract
- authors (JSONB array)
- year, venue
- citationCount
- url, pdfUrl
- isOpenAccess
- fields, keywords (JSONB)
- metadata (JSONB)

**projects**
- id (UUID, PK)
- userId (FK → users)
- name, description
- color, icon
- isShared
- createdAt, updatedAt

**project_papers** (join table)
- id (UUID, PK)
- projectId (FK → projects)
- paperId (FK → papers)
- position
- addedAt

**user_papers** (reading status)
- id (UUID, PK)
- userId (FK → users)
- paperId (FK → papers)
- status (to-read, reading, completed)
- progress (0-100)
- rating
- isFavorite
- lastReadAt

**notes**
- id (UUID, PK)
- userId (FK → users)
- paperId (FK → papers)
- projectId (FK → projects, optional)
- content
- pageNumber
- position (JSONB)
- color
- isShared

**highlights**
- id (UUID, PK)
- userId (FK → users)
- paperId (FK → papers)
- text
- pageNumber
- position (JSONB)
- color
- noteId (FK → notes, optional)

**ai_chats**
- id (UUID, PK)
- userId (FK → users)
- paperId (FK → papers, optional)
- projectId (FK → projects, optional)
- title
- messages (JSONB array)
- type
- createdAt, updatedAt

**literature_reviews**
- id (UUID, PK)
- userId (FK → users)
- projectId (FK → projects, optional)
- title, content
- paperIds (JSONB array)
- structure (JSONB)
- citationStyle

**research_gaps**
- id (UUID, PK)
- userId (FK → users)
- projectId (FK → projects, optional)
- title, description
- category
- relatedPapers (JSONB array)
- severity

**flashcards**
- id (UUID, PK)
- userId (FK → users)
- paperId (FK → papers, optional)
- question, answer
- difficulty
- nextReview
- timesReviewed

**study_sessions**
- id (UUID, PK)
- userId (FK → users)
- paperId (FK → papers, optional)
- duration (seconds)
- startedAt, endedAt

**user_stats** (denormalized)
- id (UUID, PK)
- userId (FK → users, unique)
- papersRead
- readingStreak
- totalReadingTime
- lastReadDate
- topTopics (JSONB)
- monthlyStats (JSONB)

## API Architecture

### External APIs

**Semantic Scholar**
- Endpoint: `https://api.semanticscholar.org/graph/v1/`
- Authentication: API key (optional)
- Rate Limit: 100 req/5min (without key)
- Features: Paper search, recommendations, citations

**OpenAlex**
- Endpoint: `https://api.openalex.org/`
- Authentication: None required
- Rate Limit: ~10 req/sec
- Features: Paper search, author data, institutions

**arXiv**
- Endpoint: `http://export.arxiv.org/api/query`
- Authentication: None required
- Rate Limit: ~3 req/sec
- Format: XML (Atom)

**OpenAI**
- Endpoint: `https://api.openai.com/v1/`
- Authentication: API key required
- Model: gpt-4o-mini
- Features: Chat, structured output

### Internal APIs

All API routes follow REST conventions:

**GET /api/search**
- Query papers across databases
- Parameters: q, sources, filters, limit
- Returns: Array of SearchResult

**POST /api/ai/explain**
- Generate paper explanation
- Body: { paper, level }
- Returns: { explanation }

**POST /api/ai/literature-review**
- Generate literature review
- Body: { papers, focusArea }
- Returns: { review: { introduction, sections, conclusion } }

**POST /api/ai/research-gaps**
- Find research gaps
- Body: { papers }
- Returns: { gaps: Array<Gap> }

**POST /api/ai/chat**
- Chat with AI mentor
- Body: { question, papers, chatHistory }
- Returns: { answer }

**POST /api/ai/citation**
- Generate citation
- Body: { paper, style }
- Returns: { citation }

**POST /api/ai/flashcards**
- Generate flashcards
- Body: { paper, count }
- Returns: { flashcards }

## Component Architecture

### Design System

**Base Components** (`src/components/ui/`)
- Button
- Input
- Card (+ CardHeader, CardContent, CardFooter)
- Badge
- Loading (+ LoadingSpinner, FullPageLoading)
- EmptyState

**Feature Components**
- SearchBar: Advanced paper search
- PaperCard: Paper display card
- PaperModal: Paper details modal
- ResearchChat: AI chat interface
- KnowledgeGraph: Interactive graph visualization
- ComparisonTable: Side-by-side comparison
- StatsCard: Statistics display

### Composition Pattern

Components follow composition over inheritance:

```tsx
<Card>
  <CardHeader>
    <h3>Title</h3>
  </CardHeader>
  <CardContent>
    Content here
  </CardContent>
  <CardFooter>
    Actions here
  </CardFooter>
</Card>
```

## State Management

Currently using React hooks (useState, useEffect).

**Planned: Zustand**
- Global state for user data
- Paper selections
- Chat history
- Preferences

## Performance Optimizations

### Client-Side
- Code splitting (automatic with Next.js)
- Image optimization
- Lazy loading components
- Debounced search input

### Server-Side
- API response caching
- Database query optimization
- Connection pooling
- Rate limit handling

### Database
- Indexed columns (email, externalId)
- JSONB for flexible data
- Denormalized stats table
- Efficient join tables

## Security

### API Keys
- Server-side only (never exposed to client)
- Environment variable configuration
- Runtime validation

### Database
- Parameterized queries (Drizzle ORM)
- Foreign key constraints
- Row-level security (planned)

### Authentication
- Password hashing (planned: bcrypt)
- Session management (planned: NextAuth)
- CSRF protection (Next.js built-in)

## Error Handling

### API Routes
```typescript
try {
  // Operation
  return NextResponse.json({ data });
} catch (error) {
  console.error('Error:', error);
  return NextResponse.json(
    { error: 'Error message' },
    { status: 500 }
  );
}
```

### OpenAI Functions
- Check API key availability
- Handle rate limits
- Validate responses
- Fallback messages

## Deployment

### Production Build
```bash
npm run build
```

Creates optimized bundle:
- Minified JavaScript
- Optimized CSS
- Static page generation
- Image optimization

### Environment
- Node.js 18+
- PostgreSQL 14+
- Vercel (recommended) or any Node.js host

### Database
- Managed PostgreSQL recommended
- Automatic backups
- Connection pooling
- SSL required

## Monitoring & Logging

### Current
- Console logging
- Error boundaries (planned)
- Health check endpoint

### Planned
- Structured logging
- Error tracking (Sentry)
- Performance monitoring
- Analytics

## Testing Strategy

### Unit Tests (Planned)
- Component tests (Jest + React Testing Library)
- Utility function tests
- API route tests

### Integration Tests (Planned)
- E2E tests (Playwright)
- API integration tests
- Database tests

### Manual Testing
- Cross-browser testing
- Mobile responsiveness
- Accessibility (WCAG 2.1)

## Scalability Considerations

### Current Architecture
- Supports ~1000 concurrent users
- Database connection pooling
- Stateless API design

### Future Improvements
- Redis caching
- Message queue (Bull/BullMQ)
- CDN for static assets
- Database read replicas
- Horizontal scaling

## Future Architecture

### Planned Features
- **Microservices:**
  - PDF processing service
  - Citation network analysis
  - Real-time collaboration

- **Real-time:**
  - WebSocket for live updates
  - Collaborative editing
  - Notification system

- **Advanced AI:**
  - Fine-tuned models
  - Vector embeddings (FAISS)
  - Semantic search

- **Mobile:**
  - React Native app
  - Offline support
  - Sync mechanism

## Contributing

See component and API patterns above. Follow:
- TypeScript for type safety
- Functional components
- Composition over inheritance
- Clean code principles

---

**Architecture designed for:** Simplicity, Scalability, Maintainability
