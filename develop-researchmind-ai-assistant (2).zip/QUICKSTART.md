# ResearchMind - Quick Start Guide

Get up and running with ResearchMind in 5 minutes! 🚀

## Prerequisites

- Node.js 18+ installed
- PostgreSQL 14+ running
- OpenAI API key ([Get one here](https://platform.openai.com/api-keys))

## Installation

### Step 1: Clone and Install

```bash
# Clone the repository
git clone <repository-url>
cd researchmind

# Install dependencies
npm install
```

### Step 2: Configure Environment

Create a `.env` file in the project root:

```env
# Database (Required)
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db

# OpenAI API (Required)
OPENAI_API_KEY=sk-your-actual-api-key-here

# Semantic Scholar (Optional - for higher rate limits)
SEMANTIC_SCHOLAR_API_KEY=your-semantic-scholar-key
```

### Step 3: Setup Database

```bash
# Push database schema
npx drizzle-kit push
```

### Step 4: Start Development Server

```bash
# Run in development mode
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) 🎉

## First Steps

### 1. Search for Papers

1. Enter keywords in the search bar (e.g., "transformer neural networks")
2. Click filters to refine by year, citations, or open access
3. Select data sources (Semantic Scholar, OpenAlex, arXiv)
4. Click "Search"

**Try this search:** `transformer architecture year:2017-2023`

### 2. Understand a Paper

1. Click on any paper card
2. Read the abstract and TL;DR
3. Click "AI Explanation" tab
4. Select your knowledge level (e.g., "Undergraduate")
5. Click "Generate Explanation"

**Result:** AI explains the paper at your level!

### 3. Generate Citations

1. In the paper modal, click "Citations" tab
2. Select format (APA, MLA, IEEE, Chicago, BibTeX)
3. Click "Generate Citation"
4. Click "Copy to Clipboard"

**Result:** Properly formatted citation ready to paste!

### 4. Chat with AI Mentor

1. Navigate to "Tools" in the navigation
2. Click "AI Research Mentor"
3. Ask questions like:
   - "Explain self-attention in simple terms"
   - "How does BERT differ from GPT?"
   - "What should I read to understand transformers?"
4. Get intelligent, context-aware responses

### 5. Generate Literature Review

1. Search and note 3-5 papers on a topic
2. Go to Tools → Literature Review
3. Click "Generate Review"
4. Get a structured review with:
   - Introduction
   - Thematic sections
   - Conclusion
   - Research gaps identified

### 6. View Analytics

1. Go to "Dashboard" in navigation
2. See your:
   - Papers read
   - Reading streak
   - Total reading time
   - Favorite topics
   - AI recommendations

## Core Features Overview

### 🔍 Search Papers
**What:** Search 200M+ papers across multiple databases  
**How:** Enter query → Apply filters → Click search  
**Example:** "deep learning year:2020-2024 citations:100+"

### 🧠 AI Explanations
**What:** Understand papers at your level (beginner → expert)  
**How:** Select paper → AI Explanation tab → Choose level  
**Example:** Explain "Attention Is All You Need" for undergrads

### 📚 Literature Reviews
**What:** Auto-generate comprehensive reviews  
**How:** Select papers → Tools → Generate Review  
**Example:** Compare BERT, GPT-3, and T5

### 💡 Research Gaps
**What:** Find underexplored areas and opportunities  
**How:** Select papers → Tools → Find Gaps  
**Example:** Discover gaps in transformer efficiency research

### 💬 AI Chat
**What:** Ask questions about papers and concepts  
**How:** Tools → AI Research Mentor → Ask question  
**Example:** "What mathematical background do I need?"

### 📊 Knowledge Graph
**What:** Visualize connections between papers  
**How:** Tools → Knowledge Graph → Explore  
**Example:** See how transformer papers cite each other

### 📋 Comparison Table
**What:** Compare paper metrics side-by-side  
**How:** Tools → Comparison Table → View metrics  
**Example:** Compare accuracy across different models

### 📖 Study Mode
**What:** Generate flashcards and quizzes  
**How:** Select paper → Generate flashcards  
**Example:** Create 5 flashcards for "Attention Is All You Need"

### 📝 Citations
**What:** Generate citations in 5 formats  
**How:** Paper modal → Citations tab → Select format  
**Example:** Generate APA citation for any paper

## Tips & Tricks

### Search Tips

✅ **Use specific keywords:**
- ❌ "machine learning"
- ✅ "transformer neural networks attention mechanism"

✅ **Apply filters:**
- Year range: Focus on recent papers
- Citations: Find influential work
- Open access: Get free PDFs

✅ **Combine sources:**
- Semantic Scholar: Best for CS/AI
- OpenAlex: Broad coverage
- arXiv: Latest preprints

### AI Explanation Tips

✅ **Choose the right level:**
- Beginner: High school student, no background
- Undergraduate: Basic CS knowledge
- Graduate: Familiar with concepts
- Expert: Deep technical understanding

✅ **Regenerate if needed:**
- Click "Regenerate" for different explanations
- Try different levels for various perspectives

### Literature Review Tips

✅ **Select 5-10 papers:**
- Too few: Review lacks depth
- Too many: Review becomes unfocused

✅ **Specify focus area:**
- "Transformer architectures in NLP"
- "Computer vision attention mechanisms"

✅ **Export and refine:**
- Copy generated review
- Edit and add your insights
- Use as starting point

## Common Questions

### Q: Do I need to pay for OpenAI?
**A:** Yes, you need an OpenAI API key with credits. Pricing is usage-based (~$0.15 per 1M tokens for GPT-4o-mini).

### Q: Can I use without OpenAI?
**A:** Search works without AI. Explanations, reviews, and chat require OpenAI.

### Q: How many papers can I search?
**A:** Unlimited searches! Rate limits depend on API keys:
- Semantic Scholar: ~100 req/5min (no key), 5000+ (with key)
- OpenAlex: ~10 req/sec
- arXiv: ~3 req/sec

### Q: Is my data private?
**A:** Yes! All data is stored in your local database. We don't track or sell your data.

### Q: Can I export my work?
**A:** Yes! Export literature reviews, citations, and notes. More export formats coming soon.

### Q: Does it work offline?
**A:** No, requires internet for:
- Paper search (external APIs)
- AI features (OpenAI API)
- Future: Offline mode planned

## Keyboard Shortcuts (Planned)

- `Cmd/Ctrl + K` - Quick search
- `Cmd/Ctrl + E` - Explain paper
- `Cmd/Ctrl + C` - Copy citation
- `Esc` - Close modal

## Next Steps

### Explore Features
1. Try all explanation levels
2. Generate a literature review
3. Find research gaps
4. Explore the knowledge graph
5. Create flashcards

### Customize
1. Set your default explanation level
2. Choose favorite topics
3. Create projects/collections
4. Save papers for later

### Learn More
- Read [README.md](README.md) for full features
- Check [ARCHITECTURE.md](ARCHITECTURE.md) for technical details
- See [FEATURES.md](FEATURES.md) for comparisons

## Getting Help

### Documentation
- **README.md** - Full documentation
- **SETUP.md** - Detailed setup guide
- **ARCHITECTURE.md** - Technical architecture
- **FEATURES.md** - Feature comparisons

### Support
- Open a GitHub issue
- Check existing discussions
- Read API documentation

## Production Deployment

### Build for Production

```bash
# Build optimized bundle
npm run build

# Start production server
npm start
```

### Deploy to Vercel

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel
```

Set environment variables in Vercel dashboard:
- `DATABASE_URL`
- `OPENAI_API_KEY`
- `SEMANTIC_SCHOLAR_API_KEY` (optional)

### Deploy to Other Platforms

ResearchMind works on any Node.js hosting:
- Vercel (recommended)
- Netlify
- Railway
- Render
- DigitalOcean
- AWS/GCP/Azure

## Example Workflows

### Workflow 1: Literature Review
1. Search for 5-10 papers on your topic
2. Read abstracts and select relevant ones
3. Tools → Generate Literature Review
4. Review generated content
5. Export and refine for your paper

### Workflow 2: Understand Complex Paper
1. Find the paper via search
2. Read TL;DR for overview
3. Generate AI explanation at your level
4. Ask follow-up questions in AI chat
5. Create flashcards for key concepts
6. Track as "reading" in progress

### Workflow 3: Find Research Opportunities
1. Collect 10-15 recent papers in your area
2. Tools → Research Gap Finder
3. Review identified gaps by severity
4. Explore high-severity gaps
5. Check related papers
6. Plan new research direction

### Workflow 4: Compare Approaches
1. Search for papers on similar topics
2. Note their methodologies
3. Tools → Comparison Table
4. View metrics side-by-side
5. Analyze strengths/weaknesses
6. Choose approach for your work

## Success!

You're now ready to use ResearchMind! 🎉

Start by searching for papers in your field and exploring the AI features.

**Happy researching!** 📚🔬

---

Need help? Check the [documentation](README.md) or open an issue on GitHub.
