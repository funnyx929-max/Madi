# ResearchMind - AI-Powered Research Assistant

ResearchMind is a comprehensive AI-powered research assistant that helps students and researchers understand scientific literature instead of simply summarizing it. Built with Next.js, TypeScript, PostgreSQL, and OpenAI.

![ResearchMind](https://img.shields.io/badge/Next.js-16.2.6-black)
![TypeScript](https://img.shields.io/badge/TypeScript-5.9.3-blue)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-Drizzle%20ORM-blue)
![OpenAI](https://img.shields.io/badge/AI-OpenAI%20GPT--4-green)

## 🚀 Features

### 1. **Paper Search**
- Search across multiple academic databases:
  - Semantic Scholar
  - OpenAlex
  - arXiv
- Advanced filters: year, citations, author, venue, open-access
- Recommended related papers
- TL;DR summaries for quick understanding

### 2. **AI Reading Assistant**
- Explain papers at different levels:
  - 🎓 Beginner (high school)
  - 📚 Undergraduate
  - 🔬 Graduate
  - 🏆 Expert
- Section-by-section summaries
- Highlight key contributions and limitations
- Identify assumptions and future work

### 3. **Literature Review Generator**
- Automatically generate comprehensive literature reviews
- Group papers by methodology, dataset, or research direction
- Identify agreements and disagreements
- Discover research gaps
- Export in multiple formats (PDF, Word, Markdown)

### 4. **Research Gap Finder**
- Analyze collections of papers to identify:
  - 🔍 Underexplored topics
  - ⚠️ Contradictory findings
  - 🚧 Common limitations
  - 💡 Future research directions
- Severity and category classification
- Actionable insights for new research

### 5. **Citation Assistant**
- Generate citations in multiple styles:
  - APA
  - MLA
  - IEEE
  - Chicago
  - BibTeX
- One-click copy to clipboard
- Detect missing or inconsistent references

### 6. **AI Research Mentor**
- Interactive chat interface
- Ask questions about papers:
  - "Explain this paper simply"
  - "How is this different from BERT?"
  - "What background knowledge do I need?"
  - "What are the weaknesses?"
- Context-aware responses using paper content
- Chat history for continuous conversation

### 7. **Knowledge Graph**
- Interactive visualization of research connections
- Connect:
  - 📄 Papers
  - 👤 Authors
  - 💡 Concepts
  - 🗄️ Datasets
  - 🔧 Methods
  - 🏛️ Institutions
- Explore citation networks
- Discover research communities

### 8. **Experiment Comparison Table**
- Compare papers side-by-side
- View metrics:
  - Dataset
  - Model
  - Accuracy, Precision, Recall, F1 Score
  - Limitations
  - Publication year
- Sort and filter results
- Export comparison data

### 9. **Study Mode**
- Generate AI-powered flashcards
- Create quizzes from papers
- Build concept maps
- Track reading progress
- Estimate reading time
- Spaced repetition for learning

### 10. **Dashboard & Analytics**
- 📊 Papers read statistics
- 🔥 Reading streak tracking
- ⏱️ Total reading time
- 📈 Favorite topics analysis
- 🎯 AI-powered recommendations
- 📅 Monthly reading trends

### 11. **Collaboration Features**
- Shared projects
- Notes attached to papers
- Highlight synchronization
- Export annotations
- Team research workflows

## 🛠️ Tech Stack

### Frontend
- **Framework:** Next.js 16 (App Router)
- **Language:** TypeScript
- **Styling:** Tailwind CSS 4
- **UI Components:** Custom component library
- **Visualizations:**
  - ReactFlow (Knowledge Graph)
  - Recharts (Analytics)
- **State Management:** Zustand (planned)

### Backend
- **Runtime:** Node.js
- **Database:** PostgreSQL
- **ORM:** Drizzle ORM
- **API Routes:** Next.js App Router API

### AI & APIs
- **AI Model:** OpenAI GPT-4o-mini
- **Academic APIs:**
  - Semantic Scholar API
  - OpenAlex API
  - arXiv API
  - Crossref API (planned)
  - PubMed API (planned)

### Database Schema

The application includes comprehensive database models:
- **Users:** User profiles and preferences
- **Papers:** Research paper metadata
- **Projects:** User collections and folders
- **Notes & Highlights:** Annotations and bookmarks
- **AI Chats:** Conversation history
- **Literature Reviews:** Generated reviews
- **Research Gaps:** Identified opportunities
- **Study Sessions:** Reading time tracking
- **Flashcards:** Learning aids
- **Citations:** Generated citations
- **User Stats:** Analytics and progress

## 🚀 Getting Started

### Prerequisites

- Node.js 18+ and npm
- PostgreSQL 14+
- OpenAI API key

### Installation

1. **Clone the repository:**
   ```bash
   git clone <repository-url>
   cd researchmind
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Set up environment variables:**
   
   Create a `.env` file in the project root:
   ```env
   # Database
   DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db

   # OpenAI API
   OPENAI_API_KEY=sk-your-openai-api-key

   # Optional: Academic API Keys
   SEMANTIC_SCHOLAR_API_KEY=your-semantic-scholar-key
   ```

4. **Set up the database:**
   ```bash
   # Push schema to database
   npx drizzle-kit push
   ```

5. **Run the development server:**
   ```bash
   npm run dev
   ```

6. **Open your browser:**
   Navigate to [http://localhost:3000](http://localhost:3000)

### Production Build

```bash
# Build the application
npm run build

# Start production server
npm start
```

## 📖 Usage

### Search for Papers

1. Enter keywords, authors, or topics in the search bar
2. Apply filters (year range, citations, open access)
3. Select data sources (Semantic Scholar, OpenAlex, arXiv)
4. Click "Search" to find papers

### Understand a Paper

1. Click on any paper card
2. View the abstract and metadata
3. Click "AI Explanation" tab
4. Select your knowledge level
5. Read the AI-generated explanation

### Generate Literature Review

1. Search and select multiple papers
2. Navigate to Tools → Literature Review
3. Click "Generate Review"
4. Export the review in your preferred format

### Find Research Gaps

1. Select papers from your search results
2. Navigate to Tools → Research Gaps
3. Click "Find Gaps"
4. View identified opportunities by category and severity

### Chat with AI Mentor

1. Navigate to Tools → AI Research Mentor
2. Ask questions about papers or concepts
3. Get context-aware responses
4. Continue the conversation

## 🎨 Pages

- **`/`** - Home page with search and features
- **`/dashboard`** - Personal analytics and progress
- **`/tools`** - Research tools (chat, review, gaps, graph, comparison)

## 🔌 API Endpoints

### Search
- `GET /api/search` - Search papers across multiple databases

### AI Features
- `POST /api/ai/explain` - Generate paper explanations
- `POST /api/ai/literature-review` - Generate literature reviews
- `POST /api/ai/research-gaps` - Find research gaps
- `POST /api/ai/chat` - Chat with AI mentor
- `POST /api/ai/citation` - Generate citations
- `POST /api/ai/flashcards` - Generate flashcards

## 🧪 Development

### Type Checking
```bash
npm run typecheck
```

### Build
```bash
npm run build
```

### Linting
```bash
npm run lint
```

## 🌟 Key Differentiators

ResearchMind is **not just a summarization tool**. It:

1. **Explains** papers at different knowledge levels
2. **Connects** papers through knowledge graphs
3. **Compares** methodologies and results
4. **Identifies** research gaps and opportunities
5. **Teaches** through flashcards and quizzes
6. **Mentors** through interactive AI chat
7. **Organizes** research with projects and annotations
8. **Tracks** progress and learning analytics

## 🔒 Environment Variables

Required:
- `DATABASE_URL` - PostgreSQL connection string
- `OPENAI_API_KEY` - OpenAI API key for AI features

Optional:
- `SEMANTIC_SCHOLAR_API_KEY` - For increased API rate limits

## 📊 Database

The application uses PostgreSQL with Drizzle ORM. Schema includes:
- User management and preferences
- Paper metadata and relationships
- Projects and collections
- Notes, highlights, and annotations
- AI interaction history
- Study sessions and analytics

## 🚧 Roadmap

- [ ] PDF upload and OCR processing
- [ ] Writing assistant for academic papers
- [ ] Reference manager integration (Zotero, Mendeley)
- [ ] Multi-language support
- [ ] Mobile app (React Native)
- [ ] Collaborative workspaces
- [ ] Advanced citation network analysis
- [ ] Research proposal generator
- [ ] Grant application assistant

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

MIT License - feel free to use this project for learning and research.

## 🙏 Acknowledgments

- **Semantic Scholar** - Academic search API
- **OpenAlex** - Open research metadata
- **arXiv** - Preprint repository
- **OpenAI** - GPT-4 language model
- **Next.js** - React framework
- **Drizzle ORM** - Type-safe database toolkit

## 📧 Contact

For questions, feedback, or collaboration opportunities, please open an issue on GitHub.

---

**Built with ❤️ for researchers worldwide**

*Making research accessible, understandable, and connected.*
